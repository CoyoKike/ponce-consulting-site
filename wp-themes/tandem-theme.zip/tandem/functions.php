<?php
/**
 * Tandem theme setup.
 */

add_action( 'after_setup_theme', function () {
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/css/site.css' );
} );

add_action( 'wp_enqueue_scripts', function () {
	$v   = wp_get_theme()->get( 'Version' );
	$uri = get_theme_file_uri();
	wp_enqueue_style( 'tandem-site', $uri . '/assets/css/site.css', array(), $v );
	wp_enqueue_script( 'gsap', $uri . '/assets/vendor/gsap.min.js', array(), '3', true );
	wp_enqueue_script( 'gsap-st', $uri . '/assets/vendor/ScrollTrigger.min.js', array( 'gsap' ), '3', true );
	wp_enqueue_script( 'lenis', $uri . '/assets/vendor/lenis.min.js', array(), '1', true );
	wp_enqueue_script( 'tandem-site', $uri . '/assets/js/site.js', array( 'gsap', 'gsap-st', 'lenis' ), $v, true );
} );

/** Intro flag, set before paint so nothing flashes. A safety timer always lifts it. */
add_action( 'wp_head', function () {
	echo "<script>document.documentElement.classList.add('t-intro','t-js');setTimeout(function(){document.documentElement.classList.remove('t-intro')},6000)</script>\n";
	echo '<link rel="preload" href="' . esc_url( get_theme_file_uri( 'assets/fonts/archivo.woff2' ) ) . '" as="font" type="font/woff2" crossorigin>' . "\n";
	echo '<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 40 40%27%3E%3Crect width=%2740%27 height=%2740%27 fill=%27%232337d6%27/%3E%3Crect x=%279%27 y=%279%27 width=%279%27 height=%2722%27 fill=%27%23f4f4f1%27/%3E%3Crect x=%2722%27 y=%279%27 width=%279%27 height=%2722%27 fill=%27%23f4f4f1%27/%3E%3C/svg%3E">' . "\n";
}, 1 );

/** First run: pretty links. */
add_action( 'init', function () {
	if ( get_option( 'tandem_setup_v' ) === '1' ) {
		return;
	}
	global $wp_rewrite;
	$wp_rewrite->set_permalink_structure( '/%postname%/' );
	flush_rewrite_rules();
	update_option( 'tandem_setup_v', '1' );
}, 99 );

add_action( 'init', function () {
	register_block_pattern_category( 'tandem', array( 'label' => __( 'Tandem sections', 'tandem' ) ) );
} );

/** Helper for pattern files: theme image URL. */
function tandem_img( $file ) {
	return esc_url( get_theme_file_uri( 'assets/img/' . $file ) );
}
