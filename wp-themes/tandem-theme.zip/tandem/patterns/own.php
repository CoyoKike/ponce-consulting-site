<?php
/**
 * Title: What we back
 * Slug: tandem/own
 * Categories: tandem
 */
$tandem_own = array(
	array( 'c-homecare', '64% 40%', 'The job', 'Caregivers, cooks and machinists buying the business they already run.', 'A caregiver in a gray uniform talks with a coworker at the home care agency they own together' ),
	array( 'c-housing', '38% 55%', 'The home', 'Tenants buying their building so no landlord can sell it out from under them.', 'A brick apartment building with a garden courtyard, bought by the families who rent there' ),
	array( 'elevator', '26% 40%', 'The store', 'Neighbors pooling money to open, or save, the grocery on the corner.', 'A young man laughs in the snack aisle of a member-owned corner store' ),
);
?>
<!-- wp:group {"tagName":"section","className":"own","anchor":"own","layout":{"type":"default"}} -->
<section id="own" class="wp-block-group own">
<!-- wp:heading {"className":"own-title"} -->
<h2 class="wp-block-heading own-title">Own<span class="own-colon">:</span></h2>
<!-- /wp:heading -->

<!-- wp:html -->
<div class="own-cols">
<?php foreach ( $tandem_own as $i => $o ) : ?>
  <article class="own-col own-col-<?php echo (int) $i + 1; ?>">
    <div class="own-pic"><img src="<?php echo tandem_img( $o[0] . '.webp' ); ?>" srcset="<?php echo tandem_img( $o[0] . '-m.webp' ); ?> 1000w, <?php echo tandem_img( $o[0] . '.webp' ); ?> 1600w" sizes="(max-width: 900px) 100vw, 33vw" style="object-position:<?php echo esc_attr( $o[1] ); ?>" alt="<?php echo esc_attr( $o[4] ); ?>" loading="lazy"></div>
    <h3><?php echo esc_html( $o[2] ); ?></h3>
    <p><?php echo esc_html( $o[3] ); ?></p>
  </article>
<?php endforeach; ?>
</div>
<!-- /wp:html -->
</section>
<!-- /wp:group -->
