<?php
/**
 * Title: Hero
 * Slug: tandem/hero
 * Categories: tandem
 */
?>
<!-- wp:cover {"url":"<?php echo tandem_img( 'j-own.webp' ); ?>","dimRatio":0,"focalPoint":{"x":0.74,"y":0.35},"minHeight":100,"minHeightUnit":"vh","className":"hero","anchor":"top","layout":{"type":"default"}} -->
<div id="top" class="wp-block-cover hero" style="min-height:100vh"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background" alt="A butcher in a white coat stands with his arms crossed in the doorway of the shop he co-owns" src="<?php echo tandem_img( 'j-own.webp' ); ?>" style="object-position:74% 35%" data-object-position="74% 35%" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
<!-- wp:group {"className":"hero-copy","layout":{"type":"default"}} -->
<div class="wp-block-group hero-copy">
<!-- wp:paragraph {"className":"hero-kicker"} -->
<p class="hero-kicker">Cooperative loan fund · Great Lakes</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"className":"hero-title"} -->
<h1 class="wp-block-heading hero-title"><span class="hl hl-1"><span>Ours</span></span><span class="hl hl-2"><span>to build.</span></span></h1>
<!-- /wp:heading -->

<!-- wp:group {"className":"hero-foot","layout":{"type":"default"}} -->
<div class="wp-block-group hero-foot">
<!-- wp:paragraph {"className":"hero-lede"} -->
<p class="hero-lede">Loans and training for people who want to own where they work, live and shop.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<a class="sq-btn sq-light" href="#funding"><span>Apply for funding</span><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div></div>
<!-- /wp:cover -->
