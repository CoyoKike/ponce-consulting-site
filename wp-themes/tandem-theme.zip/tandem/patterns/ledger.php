<?php
/**
 * Title: Loan ledger
 * Slug: tandem/ledger
 * Categories: tandem
 */
$tandem_loans = array(
	array( 'Nov 14', 'Cass Corridor Grocery', 'Detroit, MI', 'Store', 420000 ),
	array( 'Nov 06', 'Lakeshore Home Care Co-op', 'Milwaukee, WI', 'Job', 185000 ),
	array( 'Oct 29', 'Riverbend Tenants Association', 'Toledo, OH', 'Home', 1250000 ),
	array( 'Oct 17', 'Second Shift Machining', 'Grand Rapids, MI', 'Job', 640000 ),
	array( 'Oct 03', 'Northside Food Co-op', 'Minneapolis, MN', 'Store', 95000 ),
	array( 'Sep 22', 'Union Bakery Workers', 'Cleveland, OH', 'Job', 210000 ),
	array( 'Sep 09', 'Elm Court Housing Cooperative', 'Chicago, IL', 'Home', 980000 ),
);

/* Every chart below is worked out from the rows above, so the numbers always match the table. */
if ( ! function_exists( 'tandem_money' ) ) {
	function tandem_money( $n ) {
		if ( $n >= 1000000 ) {
			return '$' . rtrim( rtrim( number_format( $n / 1000000, 3 ), '0' ), '.' ) . 'M';
		}
		return '$' . rtrim( rtrim( number_format( $n / 1000, 1 ), '0' ), '.' ) . 'K';
	}
}
$t_total   = 0;
$t_kind    = array( 'Home' => 0, 'Job' => 0, 'Store' => 0 );
$t_month   = array();
$t_mcount  = array();
foreach ( $tandem_loans as $l ) {
	$t_total += $l[4];
	$t_kind[ $l[3] ] += $l[4];
	$m = substr( $l[0], 0, 3 );
	$t_month[ $m ]  = ( isset( $t_month[ $m ] ) ? $t_month[ $m ] : 0 ) + $l[4];
	$t_mcount[ $m ] = ( isset( $t_mcount[ $m ] ) ? $t_mcount[ $m ] : 0 ) + 1;
}
$t_month  = array_reverse( $t_month, true );
$t_mcount = array_reverse( $t_mcount, true );
$t_mmax   = max( $t_month );

/* Donut slices (pathLength 100), rounded so the shares add to 100. */
$t_pct  = array();
$t_left = 100;
$t_keys = array_keys( $t_kind );
foreach ( $t_keys as $i => $k ) {
	$t_pct[ $k ] = ( $i === count( $t_keys ) - 1 ) ? $t_left : (int) round( 100 * $t_kind[ $k ] / $t_total );
	$t_left     -= $t_pct[ $k ];
}

/* On-time repayment by year (portfolio record). */
$t_repaid = array( 2019 => 96.1, 2020 => 95.4, 2021 => 96.8, 2022 => 97.3, 2023 => 97.9, 2024 => 98.2, 2025 => 98.6, 2026 => 98.4 );
$t_lo = 94; $t_hi = 100; $t_w = 320; $t_h = 170; $t_px = 14; $t_py = 22;
$t_pts = array();
$t_i   = 0;
foreach ( $t_repaid as $y => $v ) {
	$x = $t_px + $t_i * ( $t_w - 2 * $t_px ) / ( count( $t_repaid ) - 1 );
	$yy = $t_py + ( $t_hi - $v ) / ( $t_hi - $t_lo ) * ( $t_h - 2 * $t_py );
	$t_pts[] = array( round( $x, 1 ), round( $yy, 1 ), $y, $v );
	$t_i++;
}
$t_line = 'M' . implode( ' L', array_map( function ( $p ) { return $p[0] . ' ' . $p[1]; }, $t_pts ) );
$t_last = end( $t_pts );
$t_area = $t_line . ' L' . $t_last[0] . ' ' . ( $t_h - 6 ) . ' L' . $t_pts[0][0] . ' ' . ( $t_h - 6 ) . ' Z';
?>
<!-- wp:group {"tagName":"section","className":"ledger","anchor":"ledger","layout":{"type":"default"}} -->
<section id="ledger" class="wp-block-group ledger">
<!-- wp:group {"className":"ledger-head","layout":{"type":"default"}} -->
<div class="wp-block-group ledger-head">
<!-- wp:heading {"className":"ledger-title"} -->
<h2 class="wp-block-heading ledger-title">The ledger</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"ledger-note"} -->
<p class="ledger-note">Every loan we make is public. These are the latest.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div class="ledger-table" role="table" aria-label="Recent loans">
  <div class="lrow lrow-head" role="row"><span role="columnheader">Date</span><span role="columnheader">Cooperative</span><span role="columnheader">Where</span><span role="columnheader">Owns</span><span role="columnheader" class="amt">Loan</span></div>
<?php foreach ( $tandem_loans as $l ) : ?>
  <div class="lrow" role="row"><span role="cell" class="ld"><?php echo esc_html( $l[0] ); ?></span><span role="cell" class="lc"><?php echo esc_html( $l[1] ); ?></span><span role="cell" class="lw"><?php echo esc_html( $l[2] ); ?></span><span role="cell" class="lk"><?php echo esc_html( $l[3] ); ?></span><span role="cell" class="amt"><?php echo esc_html( '$' . number_format( $l[4] ) ); ?></span></div>
<?php endforeach; ?>
  <div class="lrow lrow-total" role="row"><span role="cell" class="ld">2026</span><span role="cell" class="lc">Lent so far this year</span><span role="cell" class="lw"></span><span role="cell" class="lk"></span><span role="cell" class="amt">$6,915,000</span></div>
</div>

<div class="charts" aria-label="The ledger in charts">
  <div class="charts-head">
    <span class="lab">The seven loans above, drawn</span>
    <strong class="charts-total"><?php echo esc_html( '$' . number_format( $t_total ) ); ?></strong>
  </div>
  <div class="charts-grid">

    <figure class="chart chart-donut">
      <figcaption class="lab">What people bought</figcaption>
      <div class="donut-wrap">
        <svg viewBox="0 0 200 200" role="img" aria-label="<?php echo esc_attr( implode( ', ', array_map( function ( $k ) use ( $t_kind, $t_pct ) { return $k . ' ' . tandem_money( $t_kind[ $k ] ) . ' (' . $t_pct[ $k ] . '%)'; }, $t_keys ) ) ); ?>">
          <circle class="donut-bg" cx="100" cy="100" r="78"/>
<?php $t_off = 0; foreach ( $t_keys as $i => $k ) : ?>
          <circle class="donut-seg seg-<?php echo esc_attr( strtolower( $k ) ); ?>" cx="100" cy="100" r="78" pathLength="100" stroke-dasharray="<?php echo esc_attr( max( 0, $t_pct[ $k ] - 0.8 ) . ' ' . ( 100 - max( 0, $t_pct[ $k ] - 0.8 ) ) ); ?>" stroke-dashoffset="<?php echo esc_attr( -$t_off ); ?>" transform="rotate(-90 100 100)"/>
<?php $t_off += $t_pct[ $k ]; endforeach; ?>
        </svg>
        <div class="donut-mid"><strong><?php echo esc_html( $t_pct['Home'] ); ?>%</strong><span>went to homes</span></div>
      </div>
      <ul class="chart-key">
<?php foreach ( $t_keys as $k ) : ?>
        <li><i class="key-<?php echo esc_attr( strtolower( $k ) ); ?>"></i><span><?php echo esc_html( $k ); ?></span><b><?php echo esc_html( tandem_money( $t_kind[ $k ] ) ); ?></b></li>
<?php endforeach; ?>
      </ul>
    </figure>

    <figure class="chart chart-bars">
      <figcaption class="lab">Lent by month</figcaption>
      <svg viewBox="0 0 300 230" role="img" aria-label="<?php echo esc_attr( implode( ', ', array_map( function ( $m ) use ( $t_month, $t_mcount ) { return $m . ' ' . tandem_money( $t_month[ $m ] ) . ' in ' . $t_mcount[ $m ] . ' loans'; }, array_keys( $t_month ) ) ) ); ?>">
        <line class="axis" x1="0" y1="190" x2="300" y2="190"/>
<?php $t_i = 0; foreach ( $t_month as $m => $v ) : $bh = round( 150 * $v / $t_mmax, 1 ); $bx = 14 + $t_i * 100; ?>
        <rect class="bar<?php echo $v === $t_mmax ? ' bar-top' : ''; ?>" x="<?php echo esc_attr( $bx ); ?>" y="<?php echo esc_attr( 190 - $bh ); ?>" width="72" height="<?php echo esc_attr( $bh ); ?>"/>
        <text class="bar-val" x="<?php echo esc_attr( $bx + 36 ); ?>" y="<?php echo esc_attr( 190 - $bh - 10 ); ?>"><?php echo esc_html( tandem_money( $v ) ); ?></text>
        <text class="bar-lab" x="<?php echo esc_attr( $bx + 36 ); ?>" y="208"><?php echo esc_html( strtoupper( $m ) ); ?></text>
        <text class="bar-sub" x="<?php echo esc_attr( $bx + 36 ); ?>" y="222"><?php echo esc_html( $t_mcount[ $m ] . ' LOANS' ); ?></text>
<?php $t_i++; endforeach; ?>
      </svg>
    </figure>

    <figure class="chart chart-line">
      <figcaption class="lab">Repaid on time, by year</figcaption>
      <div class="line-big"><strong><?php echo esc_html( $t_last[3] ); ?>%</strong><span>of payments on time in <?php echo esc_html( $t_last[2] ); ?></span></div>
      <svg viewBox="0 0 <?php echo (int) $t_w; ?> <?php echo (int) ( $t_h + 18 ); ?>" role="img" aria-label="<?php echo esc_attr( implode( ', ', array_map( function ( $p ) { return $p[2] . ' ' . $p[3] . '%'; }, $t_pts ) ) ); ?>">
        <line class="grid" x1="0" x2="<?php echo (int) $t_w; ?>" y1="<?php echo esc_attr( $t_py ); ?>" y2="<?php echo esc_attr( $t_py ); ?>"/>
        <text class="grid-lab" x="<?php echo (int) $t_w; ?>" y="<?php echo esc_attr( $t_py - 6 ); ?>">100%</text>
        <path class="line-area" d="<?php echo esc_attr( $t_area ); ?>"/>
        <path class="line-path" d="<?php echo esc_attr( $t_line ); ?>" pathLength="1"/>
<?php foreach ( $t_pts as $p ) : ?>
        <circle class="line-dot<?php echo $p === $t_last ? ' line-dot-last' : ''; ?>" cx="<?php echo esc_attr( $p[0] ); ?>" cy="<?php echo esc_attr( $p[1] ); ?>" r="<?php echo $p === $t_last ? 6 : 3.5; ?>"/>
<?php endforeach; ?>
        <text class="grid-lab" x="<?php echo esc_attr( $t_pts[0][0] ); ?>" y="<?php echo (int) ( $t_h + 14 ); ?>" text-anchor="start"><?php echo esc_html( $t_pts[0][2] ); ?></text>
        <text class="grid-lab" x="<?php echo esc_attr( $t_last[0] ); ?>" y="<?php echo (int) ( $t_h + 14 ); ?>"><?php echo esc_html( $t_last[2] ); ?></text>
      </svg>
    </figure>

  </div>
</div>
<!-- /wp:html -->
</section>
<!-- /wp:group -->
