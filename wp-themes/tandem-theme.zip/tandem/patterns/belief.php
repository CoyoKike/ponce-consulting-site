<?php
/**
 * Title: What we believe
 * Slug: tandem/belief
 * Categories: tandem
 */
?>
<!-- wp:group {"tagName":"section","className":"belief","anchor":"belief","layout":{"type":"default"}} -->
<section id="belief" class="wp-block-group belief">
<!-- wp:html -->
<figure class="belief-photo"><div class="belief-frame"><img src="<?php echo tandem_img( 'grain.webp' ); ?>" srcset="<?php echo tandem_img( 'grain-m.webp' ); ?> 1000w, <?php echo tandem_img( 'grain.webp' ); ?> 1600w" sizes="(max-width: 900px) 100vw, 50vw" alt="A smiling older woman in a leopard-print jacket sits in the secondhand shop she co-owns" loading="lazy"></div></figure>
<!-- /wp:html -->

<!-- wp:group {"className":"belief-text","layout":{"type":"default"}} -->
<div class="wp-block-group belief-text">
<!-- wp:paragraph {"className":"belief-big"} -->
<p class="belief-big">The people who do the work, rent the homes and shop the aisles should own them.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"belief-small"} -->
<p class="belief-small">So we lend, train and stand beside them until shared ownership is simply how a neighborhood works.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
