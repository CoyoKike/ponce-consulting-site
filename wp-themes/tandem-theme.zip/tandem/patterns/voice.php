<?php
/**
 * Title: Member voice
 * Slug: tandem/voice
 * Categories: tandem
 */
?>
<!-- wp:group {"tagName":"section","className":"voice","anchor":"voice","layout":{"type":"default"}} -->
<section id="voice" class="wp-block-group voice">
<!-- wp:html -->
<figure class="voice-photo"><div class="voice-frame"><img src="<?php echo tandem_img( 'band.webp' ); ?>" srcset="<?php echo tandem_img( 'band-m.webp' ); ?> 1000w, <?php echo tandem_img( 'band.webp' ); ?> 1600w" sizes="(max-width: 900px) 100vw, 45vw" alt="Luis Ortega in a blue polo shirt stands in an aisle of the grocery store he co-owns" loading="lazy"></div></figure>
<!-- /wp:html -->

<!-- wp:group {"className":"voice-text","layout":{"type":"default"}} -->
<div class="wp-block-group voice-text">
<!-- wp:html -->
<blockquote class="voice-quote"><p>None of us could buy the store alone. Together, we own it outright.</p><footer><strong>Luis Ortega</strong><span>Member-owner, Cass Corridor Grocery, Detroit</span></footer></blockquote>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
