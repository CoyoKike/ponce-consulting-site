<?php
/**
 * Title: Funding by stage
 * Slug: tandem/funding
 * Categories: tandem
 */
$tandem_funds = array(
	array( '$25K', 'Startup grants', 'Feasibility studies, bylaws and the first member drive.', 'Due April 10' ),
	array( '$2M', 'Bridge loans', 'Patient money for equipment, buildings and slow seasons.', 'Rolling' ),
	array( '$40K', 'Worker buyouts', 'When an owner retires, the staff buys the business.', 'Due May 1' ),
	array( '$75K', 'Resident-owned housing', 'Tenants organizing to buy and run their building.', 'Due April 17' ),
	array( '8 wks', 'Co-op Academy', 'Evening classes on finance, governance and growth.', 'Spring class March 3' ),
);
?>
<!-- wp:group {"tagName":"section","className":"funding","anchor":"funding","layout":{"type":"default"}} -->
<section id="funding" class="wp-block-group funding">
<!-- wp:html -->
<div class="fund-track">
  <div class="fund-panel fund-intro">
    <h2>Funding,<br>by stage.</h2>
    <p>From the first meeting to the hundredth member.</p>
  </div>
<?php foreach ( $tandem_funds as $i => $f ) : ?>
  <article class="fund-panel">
    <span class="fund-n"><?php echo esc_html( sprintf( '%d/%d', $i + 1, count( $tandem_funds ) ) ); ?></span>
    <strong class="fund-amt"><?php echo esc_html( $f[0] ); ?></strong>
    <h3><?php echo esc_html( $f[1] ); ?></h3>
    <p><?php echo esc_html( $f[2] ); ?></p>
    <div class="fund-foot"><span><?php echo esc_html( $f[3] ); ?></span><a href="mailto:hello@tandemfund.org?subject=<?php echo rawurlencode( $f[1] ); ?>">Apply <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a></div>
  </article>
<?php endforeach; ?>
</div>
<!-- /wp:html -->
</section>
<!-- /wp:group -->
