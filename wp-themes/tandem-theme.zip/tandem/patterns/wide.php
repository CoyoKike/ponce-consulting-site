<?php
/**
 * Title: Wide photo
 * Slug: tandem/wide
 * Categories: tandem
 */
?>
<!-- wp:group {"tagName":"section","className":"wide","anchor":"wide","layout":{"type":"default"}} -->
<section id="wide" class="wp-block-group wide">
<!-- wp:html -->
<div class="wide-frame"><img src="<?php echo tandem_img( 'c-housing.webp' ); ?>" srcset="<?php echo tandem_img( 'c-housing-m.webp' ); ?> 1000w, <?php echo tandem_img( 'c-housing.webp' ); ?> 1600w" sizes="100vw" alt="A brick apartment building with a garden courtyard, owned by the families who live there" loading="lazy"></div>
<div class="wide-copy">
  <p class="wide-line"><span class="wl"><span>Bought by</span></span><span class="wl wl-2"><span>the people</span></span><span class="wl"><span>inside.</span></span></p>
  <p class="wide-cap lab">Elm Court Housing Cooperative · Chicago · $980,000 loan</p>
</div>
<!-- /wp:html -->
</section>
<!-- /wp:group -->
