<?php
/**
 * Title: Give
 * Slug: tandem/give
 * Categories: tandem
 */
?>
<!-- wp:group {"tagName":"section","className":"give","anchor":"give","layout":{"type":"default"}} -->
<section id="give" class="wp-block-group give">
<!-- wp:html -->
<div class="give-grid">
  <div class="give-left">
    <h2 class="give-title">Put your money<br>to work.</h2>
    <figure class="split" aria-labelledby="splitTitle">
      <figcaption class="lab" id="splitTitle">Where your <span data-split-amt>$100</span> goes</figcaption>
      <svg class="split-bar" viewBox="0 0 1000 64" preserveAspectRatio="none" role="img" aria-label="62% training and expert help, 24% startup grants, 14% running the fund">
        <rect class="sp sp-1" x="0" y="0" width="616" height="64"/>
        <rect class="sp sp-2" x="620" y="0" width="236" height="64"/>
        <rect class="sp sp-3" x="860" y="0" width="140" height="64"/>
      </svg>
      <ul class="split-key">
        <li><b data-share="62">$62</b><span>Training and expert help</span></li>
        <li><b data-share="24">$24</b><span>Startup grants</span></li>
        <li><b data-share="14">$14</b><span>Running the fund</span></li>
      </ul>
    </figure>
    <figure class="give-photo"><img src="<?php echo tandem_img( 'j-pool.webp' ); ?>" srcset="<?php echo tandem_img( 'j-pool-m.webp' ); ?> 1000w, <?php echo tandem_img( 'j-pool.webp' ); ?> 2400w" sizes="(max-width: 900px) 100vw, 50vw" alt="Members of a garden cooperative share a meal at long tables under an umbrella" loading="lazy"></figure>
  </div>
  <form class="give-form" id="giveForm" onsubmit="return false">
    <fieldset class="give-amts">
      <legend>Amount</legend>
      <label><input type="radio" name="amt" value="$50"><span>$50</span></label>
      <label><input type="radio" name="amt" value="$100" checked><span>$100</span></label>
      <label><input type="radio" name="amt" value="$250"><span>$250</span></label>
      <label><input type="radio" name="amt" value="$500"><span>$500</span></label>
    </fieldset>
    <fieldset class="give-freq">
      <legend>How often</legend>
      <label><input type="radio" name="freq" value="Once" checked><span>Once</span></label>
      <label><input type="radio" name="freq" value="Monthly"><span>Monthly</span></label>
    </fieldset>
    <p class="give-what" id="giveWhat">$100 pays for a day of expert help for a new co-op.</p>
    <button class="sq-btn sq-light give-btn" id="giveBtn" type="submit"><span>Give $100</span><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></button>
    <p class="give-alt">Or <a href="mailto:invest@tandemfund.org">invest in the loan fund</a> and earn a modest return.</p>
  </form>
</div>
<!-- /wp:html -->
</section>
<!-- /wp:group -->
