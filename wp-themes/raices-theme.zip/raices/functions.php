<?php
/**
 * Raíces theme setup.
 */

add_action( 'after_setup_theme', function () {
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/css/site.css' );
} );

add_action( 'wp_enqueue_scripts', function () {
	$v   = wp_get_theme()->get( 'Version' );
	$uri = get_theme_file_uri();
	wp_enqueue_style( 'raices-site', $uri . '/assets/css/site.css', array(), $v );
	wp_enqueue_script( 'gsap', $uri . '/assets/vendor/gsap.min.js', array(), '3', true );
	wp_enqueue_script( 'gsap-st', $uri . '/assets/vendor/ScrollTrigger.min.js', array( 'gsap' ), '3', true );
	wp_enqueue_script( 'lenis', $uri . '/assets/vendor/lenis.min.js', array(), '1', true );
	wp_enqueue_script( 'raices-site', $uri . '/assets/js/site.js', array( 'gsap', 'gsap-st', 'lenis' ), $v, true );
} );

/** Loader flag, set before paint so nothing flashes. Never runs in the editor. */
add_action( 'wp_head', function () {
	echo "<script>document.documentElement.classList.add('r-intro','r-js');setTimeout(function(){document.documentElement.classList.remove('r-intro')},7000)</script>\n";
	echo '<link rel="preload" href="' . esc_url( get_theme_file_uri( 'assets/fonts/bricolage.woff2' ) ) . '" as="font" type="font/woff2" crossorigin>' . "\n";
}, 1 );

/** First run: make sure the About and Contact pages exist and pretty links work. */
add_action( 'init', function () {
	if ( get_option( 'raices_setup_v' ) === '2' ) {
		return;
	}
	foreach ( array( 'about' => 'About', 'contact' => 'Contact' ) as $slug => $title ) {
		if ( ! get_page_by_path( $slug ) ) {
			wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => $slug, 'post_title' => $title ) );
		}
	}
	global $wp_rewrite;
	$wp_rewrite->set_permalink_structure( '/%postname%/' );
	flush_rewrite_rules();
	update_option( 'raices_setup_v', '2' );
}, 99 );

add_action( 'init', function () {
	register_block_pattern_category( 'raices', array( 'label' => __( 'Raíces sections', 'raices' ) ) );
} );

/** Helper for pattern files: theme image URL. */
function raices_img( $file ) {
	return esc_url( get_theme_file_uri( 'assets/img/' . $file ) );
}
