<?php
/**
 * Title: How a family stays (scroll story)
 * Slug: raices/journey
 * Categories: raices
 */
?>
<!-- wp:html -->
<section class="journey" id="how" aria-label="How a family stays in Cedar Hill">
  <div class="journey-stage">
    <div class="journey-layer"><img src="<?php echo raices_img( 'homes.webp' ); ?>" alt="A street of brick row houses in the neighborhood" loading="lazy" decoding="async"></div>
    <div class="journey-layer"><img src="<?php echo raices_img( 'prog-1.webp' ); ?>" alt="A sunny courtyard between affordable apartment buildings" loading="lazy" decoding="async"></div>
    <div class="journey-layer"><img src="<?php echo raices_img( 'prog-5.webp' ); ?>" alt="A shop owner standing in the doorway of his store" loading="lazy" decoding="async"></div>
    <div class="journey-layer"><img src="<?php echo raices_img( 'give.webp' ); ?>" alt="Neighbors filling the street at a night festival" loading="lazy" decoding="async"></div>
    <div class="journey-copy">
      <div class="journey-step"><p class="label mono">A family arrives</p><h2>Rents keep <em>climbing.</em></h2></div>
      <div class="journey-step"><p class="label mono">We find them a home</p><h2>One that stays <em>affordable.</em></h2></div>
      <div class="journey-step"><p class="label mono">They build a living</p><h2>A better job. <em>A shop of their own.</em></h2></div>
      <div class="journey-step"><p class="label mono">And they stay</p><h2>Cedar Hill <em>stays theirs.</em></h2></div>
    </div>
    <ol class="jdots" aria-hidden="true"><li class="on"><span class="mono">Arrive</span></li><li><span class="mono">Home</span></li><li><span class="mono">Grow</span></li><li><span class="mono">Stay</span></li></ol>
  </div>
</section>
<!-- /wp:html -->
