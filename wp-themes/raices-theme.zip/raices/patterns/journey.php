<?php
/**
 * Title: How a family stays (scroll story)
 * Slug: raices/journey
 * Categories: raices
 */
?>
<!-- wp:html -->
<section class="journey" id="how" aria-label="How a family stays in Cedar Hill">
  <div class="journey-stage">
    <div class="journey-layer"><img src="<?php echo raices_img( 'j-1.webp' ); ?>" alt="Brownstone stoops along a tree-lined street" loading="lazy" decoding="async"></div>
    <div class="journey-layer"><img src="<?php echo raices_img( 'j-2.webp' ); ?>" alt="New affordable apartment buildings around a garden courtyard" loading="lazy" decoding="async"></div>
    <div class="journey-layer"><img src="<?php echo raices_img( 'j-3.webp' ); ?>" alt="A shop owner sitting in the open doorway of his store" loading="lazy" decoding="async"></div>
    <div class="journey-layer j-last"><img src="<?php echo raices_img( 'j-4.webp' ); ?>" alt="A woman dancing in a festival dress" loading="lazy" decoding="async"></div>
    <div class="journey-copy">
      <div class="journey-step"><p class="label mono">A family arrives</p><h2>Rents keep <em>climbing.</em></h2></div>
      <div class="journey-step"><p class="label mono">We find them a home</p><h2>One that stays <em>affordable.</em></h2></div>
      <div class="journey-step"><p class="label mono">They build a living</p><h2>A better job. <em>A shop of their own.</em></h2></div>
      <div class="journey-step"><p class="label mono">And they stay</p><h2>Cedar Hill <em>stays theirs.</em></h2></div>
    </div>
    <ol class="jdots" aria-hidden="true"><li class="on"><span class="mono">Arrive</span></li><li><span class="mono">Home</span></li><li><span class="mono">Grow</span></li><li><span class="mono">Stay</span></li></ol>
  </div>
</section>
<!-- /wp:html -->
