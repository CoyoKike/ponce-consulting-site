<?php
/**
 * Title: Contact page
 * Slug: raices/contact
 * Categories: raices
 */
?>
<!-- wp:cover {"url":"<?php echo raices_img( 'contact-hero.webp' ); ?>","dimRatio":0,"minHeight":80,"minHeightUnit":"vh","className":"hero hero--page","anchor":"top","layout":{"type":"default"}} -->
<div id="top" class="wp-block-cover hero hero--page" style="min-height:80vh"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background" alt="A painted plaza between brick buildings with neighbors and a market" src="<?php echo raices_img( 'contact-hero.webp' ); ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
<!-- wp:group {"className":"hero-copy","layout":{"type":"default"}} -->
<div class="wp-block-group hero-copy">
<!-- wp:paragraph {"className":"eyebrow mono"} -->
<p class="eyebrow mono"><span>Contact</span></p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"className":"hero-title"} -->
<h1 class="wp-block-heading hero-title"><span class="line"><span>Come by.</span></span><span class="line"><span><em>Se habla español.</em></span></span></h1>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->
</div></div>
<!-- /wp:cover -->

<!-- wp:group {"tagName":"section","className":"statement contact-sec","layout":{"type":"default"}} -->
<section class="wp-block-group statement contact-sec">
<!-- wp:html -->
<div class="info-grid">
  <div class="info-col"><p class="label mono">Visit</p><h3>1200 Linden Street</h3><p>Cedar Hill, MA 02100<br>Monday to Friday, 9 to 5</p></div>
  <div class="info-col"><p class="label mono">Call</p><h3>617-555-0142</h3><p>TTY 711<br>Hablamos español</p></div>
  <div class="info-col"><p class="label mono">Walk-in help</p><h3>No appointment needed</h3><p>Housing help: weekdays 9 to 5<br>Free tax prep: Tue &amp; Thu, 5 to 8</p></div>
</div>
<div class="contact-grid">
  <form class="contact-form" id="contactForm">
    <p class="label mono">Send a message</p>
    <label for="cf-name">Your name</label><input id="cf-name" type="text" autocomplete="name">
    <label for="cf-email">Email or phone</label><input id="cf-email" type="text" autocomplete="email">
    <label for="cf-topic">I need help with</label>
    <select id="cf-topic"><option>Finding a home</option><option>A job or training</option><option>Taxes or money</option><option>My business</option><option>Something else</option></select>
    <label for="cf-msg">Message</label><textarea id="cf-msg" rows="4"></textarea>
    <button class="btn btn-amber" type="submit"><span>Send</span></button>
    <p class="form-note mono" id="cfNote">Preview only. Nothing is sent.</p>
  </form>
  <div class="faq">
    <p class="label mono">Good to know</p>
    <details open><summary>Do I need an appointment?</summary><p>No. Walk in during office hours and someone will help you the same day.</p></details>
    <details><summary>Does it cost anything?</summary><p>Never. Every Raíces program is free for Cedar Hill residents.</p></details>
    <details><summary>Can I get help in Spanish?</summary><p>Yes. Most of our staff speak Spanish, and we can arrange Haitian Creole, Portuguese and Vietnamese.</p></details>
    <details><summary>How do waitlists work?</summary><p>Fill out one form and we add you to every building you qualify for. We call you when a home opens.</p></details>
  </div>
</div>
<!-- /wp:html -->
</section>
<!-- /wp:group -->
