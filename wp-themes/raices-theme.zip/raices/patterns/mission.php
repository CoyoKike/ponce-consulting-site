<?php
/**
 * Title: Mission
 * Slug: raices/mission
 * Categories: raices
 */
?>
<!-- wp:group {"tagName":"section","className":"statement mission","anchor":"about","layout":{"type":"default"}} -->
<section id="about" class="wp-block-group statement mission">
<!-- wp:group {"className":"statement-inner","layout":{"type":"default"}} -->
<div class="wp-block-group statement-inner">
<!-- wp:paragraph {"className":"label mono"} -->
<p class="label mono">Our mission</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"statement-text","anchor":"statementText"} -->
<p id="statementText" class="statement-text">To keep Cedar Hill <em>home</em> for the families who built it, with homes they can afford, work that pays and shops that stay open.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
