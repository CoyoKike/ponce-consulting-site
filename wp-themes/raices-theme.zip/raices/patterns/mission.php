<?php
/**
 * Title: Mission
 * Slug: raices/mission
 * Categories: raices
 */
?>
<!-- wp:group {"tagName":"section","className":"statement mission","anchor":"about","layout":{"type":"default"}} -->
<section id="about" class="wp-block-group statement mission">
<!-- wp:group {"className":"statement-inner","layout":{"type":"default"}} -->
<div class="wp-block-group statement-inner">
<!-- wp:paragraph {"className":"label mono"} -->
<p class="label mono">01 / Our mission</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"statement-text","anchor":"statementText"} -->
<p id="statementText" class="statement-text">We believe the families who raise their kids here, open the shops and care for our elders should <em>get to stay.</em></p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<div class="statement-figs">
  <figure class="sfig sfig-a" data-speed="-0.16"><img src="<?php echo raices_img( 'fig-a.webp' ); ?>" alt="A grandmother laughing with her baby grandson" loading="lazy" decoding="async"></figure>
  <figure class="sfig sfig-b" data-speed="0.12"><img src="<?php echo raices_img( 'fig-b.webp' ); ?>" alt="Two friends laughing together in the park" loading="lazy" decoding="async"></figure>
</div>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
