<?php
/**
 * Title: Homes and waitlists
 * Slug: raices/homes
 * Categories: raices
 */
$raices_homes = array(
	array( 'home-1.webp', 'Linden Street Commons', 'Open', '1–3 BR · Families · up to 60% AMI', 'From $1,150', '/mo', 'Join the waitlist', 'A modern apartment building with balconies against a clear sky' ),
	array( 'home-2.webp', 'Calder Square', 'Open', 'Studio–1 BR · Seniors 62+', 'From $890', '/mo', 'Apply now', 'A tall brick apartment building with glass bays' ),
	array( 'home-3.webp', 'Juniper Gardens', 'Coming soon', '2–3 BR · Families · lottery in March', 'From $1,420', '/mo', 'Get notified', 'An apartment building with colorful balconies' ),
	array( 'home-4.webp', 'Willow Street Homes', 'Closed', '1–2 BR · Mixed income', 'From $1,040', '/mo', 'See details', 'Brick row houses with a red front door on a tree-lined street' ),
	array( 'home-5.webp', 'Ridgeview Lofts', 'Coming soon', '1–3 BR · 64 new homes in 2027', 'From $1,280', '/mo', 'Get notified', 'Two new white apartment buildings with deep-set windows' ),
	array( 'home-6.webp', 'Maple Row', 'Open', '2–3 BR · First-time buyers', 'Own from $289K', '', 'Take the class', 'An apartment building with lit windows at dusk' ),
);
?>
<!-- wp:group {"tagName":"section","className":"hall homes","anchor":"homes","layout":{"type":"default"}} -->
<section id="homes" class="wp-block-group hall homes">
<!-- wp:html -->
<div class="homes-head">
  <div>
    <p class="label mono">Homes &amp; waitlists</p>
    <h2 class="h-big">Find a home <em>you can afford.</em></h2>
  </div>
  <div class="hall-bar">
    <label class="sr" for="hofQ">Search buildings</label>
    <input id="hofQ" type="search" placeholder="Search buildings" autocomplete="off">
    <div class="sectors" role="group" aria-label="Filter by status" id="hofS"></div>
  </div>
</div>
<p class="hall-count mono" id="hofCount" aria-live="polite"></p>
<ul class="listings" id="hofList">
<?php foreach ( $raices_homes as $h ) : $st = sanitize_title( $h[2] ); ?>
  <li class="lst" data-status="<?php echo esc_attr( $h[2] ); ?>"><a href="#homes">
    <figure class="lst-media"><img src="<?php echo raices_img( $h[0] ); ?>" alt="<?php echo esc_attr( $h[7] ); ?>" loading="lazy" decoding="async"><span class="lst-st st-<?php echo esc_attr( $st ); ?>"><?php echo esc_html( $h[2] ); ?></span></figure>
    <div class="lst-body">
      <div class="lst-top"><h3><?php echo esc_html( $h[1] ); ?></h3><span class="lst-price"><?php echo esc_html( $h[4] ); ?><small><?php echo esc_html( $h[5] ); ?></small></span></div>
      <p><?php echo esc_html( $h[3] ); ?></p>
      <span class="more mono"><?php echo esc_html( $h[6] ); ?> →</span>
    </div>
  </a></li>
<?php endforeach; ?>
</ul>
<!-- /wp:html -->
</section>
<!-- /wp:group -->
