<?php
/**
 * Title: Homes and waitlists
 * Slug: raices/homes
 * Categories: raices
 */
?>
<!-- wp:group {"tagName":"section","className":"hall","anchor":"homes","layout":{"type":"default"}} -->
<section id="homes" class="wp-block-group hall">
<!-- wp:html -->
<div class="hall-grid">
  <div class="hall-intro">
    <p class="label mono">Homes &amp; waitlists</p>
    <h2 class="h-big">Find a home <em>you can afford.</em></h2>
    <figure class="hall-fig"><img src="<?php echo raices_img( 'homes.webp' ); ?>" alt="A brick corner building with a large mural of a woman" loading="lazy" decoding="async"></figure>
  </div>
  <div class="hall-list-wrap">
    <div class="hall-bar">
      <label class="sr" for="hofQ">Search buildings</label>
      <input id="hofQ" type="search" placeholder="Search by building or street" autocomplete="off">
      <div class="sectors" role="group" aria-label="Filter by status" id="hofS"></div>
    </div>
    <p class="hall-count mono" id="hofCount" aria-live="polite"></p>
    <ol class="hall-list" id="hofList"></ol>
  </div>
</div>
<!-- /wp:html -->
</section>
<!-- /wp:group -->
