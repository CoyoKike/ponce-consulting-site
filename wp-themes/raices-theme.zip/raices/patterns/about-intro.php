<?php
/**
 * Title: About intro (home)
 * Slug: raices/about-intro
 * Categories: raices
 */
?>
<!-- wp:html -->
<section class="who-sec" id="who" aria-label="About Raíces">
<div class="who-grid">
  <figure class="who-photo page-photo"><img src="<?php echo raices_img( 'about-hero.webp' ); ?>" alt="Women in white and red dresses dancing in a neighborhood parade" loading="lazy" decoding="async"></figure>
  <div class="who-copy">
    <p class="label mono">About us</p>
    <p class="who-big">Started by twelve tenants on Linden Street. <em>Still run by the neighborhood.</em></p>
    <p class="who-small">Since 1981 we have kept Cedar Hill home for the families who built it. Today we are 48 staff and 2,000 members. Meet the people behind the work and read how it all began.</p>
    <div class="who-faces"><ul><li><img src="<?php echo raices_img( 'team-1.webp' ); ?>" alt="Marisol Vega" loading="lazy" decoding="async"></li><li><img src="<?php echo raices_img( 'team-2.webp' ); ?>" alt="Darnell Brooks" loading="lazy" decoding="async"></li><li><img src="<?php echo raices_img( 'team-3.webp' ); ?>" alt="Priya Raman" loading="lazy" decoding="async"></li><li><img src="<?php echo raices_img( 'team-4.webp' ); ?>" alt="Samir Qureshi" loading="lazy" decoding="async"></li><li><img src="<?php echo raices_img( 'team-5.webp' ); ?>" alt="Keisha Ward" loading="lazy" decoding="async"></li></ul><span class="mono">Marisol, Darnell, Priya, Samir, Keisha and the team</span></div>
    <a class="btn btn-amber btn-xl" href="/about/"><span>Our story &amp; team →</span></a>
  </div>
</div>
</section>
<!-- /wp:html -->
