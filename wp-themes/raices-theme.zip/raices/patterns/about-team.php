<?php
/**
 * Title: About — team and board
 * Slug: raices/about-team
 * Categories: raices
 */
$raices_team = array(
	array( 'team-2.webp', 'Darnell Brooks', 'Director of Housing', 'Oversees our 1,100 homes and the 200 more in the pipeline. Former Raíces resident.' ),
	array( 'team-3.webp', 'Priya Raman', 'Director of Family Prosperity', 'Grew our free tax clinic from 40 returns to 3,000 a year.' ),
	array( 'team-4.webp', 'Samir Qureshi', 'Small Business Lending', 'Has closed 140 microloans for the shops on Linden and Centre Street.' ),
	array( 'team-5.webp', 'Keisha Ward', 'Director of Organizing', 'Started knocking doors at 19. Now trains 60 tenant leaders a year.' ),
	array( 'team-6.webp', 'Claire Donovan', 'Finance &amp; Operations', 'Keeps the books clean and the lights on. CPA, twenty years in nonprofits.' ),
	array( 'team-8.webp', 'Elena Duarte', 'Homeownership Counselor', 'Has walked 400 first-time buyers to the closing table, in English and Spanish.' ),
);
$raices_board = array(
	array( 'team-7.webp', 'Walter Brennan', 'Chair', 'Retired teacher, Cedar Hill homeowner since 1976' ),
	array( 'board-2.webp', 'Ana Lucía Ortiz', 'Vice Chair', 'Linden Street Commons resident' ),
	array( 'board-3.webp', 'James Okafor', 'Treasurer', 'Credit union lender' ),
	array( 'board-4.webp', 'Rosa Martínez', 'Secretary', 'Parent leader at the Eastside school' ),
	array( 'board-5.webp', 'Hye-jin Park', 'Member', 'Owns a bakery on Centre Street' ),
	array( 'board-6.webp', 'Luis Fernández', 'Member', 'Tenant organizer at Calder Square' ),
);
?>
<!-- wp:group {"tagName":"section","className":"team-sec","anchor":"team","layout":{"type":"default"}} -->
<section id="team" class="wp-block-group team-sec">
<!-- wp:html -->
<div class="team-head">
  <p class="label mono">Our team</p>
  <h2 class="h-big">The people who <em>show up.</em></h2>
</div>
<div class="lead">
  <figure class="lead-photo"><img src="<?php echo raices_img( 'team-1.webp' ); ?>" alt="Portrait of Marisol Vega, smiling" loading="lazy" decoding="async"></figure>
  <div class="lead-copy">
    <blockquote class="lead-quote">“I grew up three blocks from our first building. <em>Nobody should have to leave the place that raised them.”</em></blockquote>
    <div class="lead-meta"><b>Marisol Vega</b><span>Executive Director</span><p>Joined Raíces as a tenant organizer in 1998 and has led it since 2012.</p></div>
  </div>
</div>
<ul class="people">
<?php foreach ( $raices_team as $p ) : ?>
  <li class="person">
    <figure class="person-photo"><img src="<?php echo raices_img( $p[0] ); ?>" alt="Portrait of <?php echo esc_attr( $p[1] ); ?>" loading="lazy" decoding="async"></figure>
    <div class="person-body"><h3><?php echo esc_html( $p[1] ); ?></h3><p class="role"><?php echo $p[2]; ?></p><p class="bio"><?php echo esc_html( $p[3] ); ?></p></div>
  </li>
<?php endforeach; ?>
</ul>
<div class="board">
  <p class="label mono">Board of directors</p>
  <ul class="board-grid">
<?php foreach ( $raices_board as $b ) : ?>
    <li class="person person--sm">
      <figure class="person-photo"><img src="<?php echo raices_img( $b[0] ); ?>" alt="Portrait of <?php echo esc_attr( $b[1] ); ?>" loading="lazy" decoding="async"></figure>
      <div class="person-body"><h3><?php echo esc_html( $b[1] ); ?></h3><p class="role"><?php echo esc_html( $b[2] ); ?></p><p class="bio"><?php echo esc_html( $b[3] ); ?></p></div>
    </li>
<?php endforeach; ?>
  </ul>
</div>
<!-- /wp:html -->
</section>
<!-- /wp:group -->
