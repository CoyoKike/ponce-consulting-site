<?php
/**
 * Title: Program — Tenant Organizing
 * Slug: raices/program-tenant-organizing
 * Categories: raices
 */
?>
<!-- wp:cover {"url":"<?php echo raices_img( 'prog-6.webp' ); ?>","dimRatio":0,"minHeight":86,"minHeightUnit":"vh","className":"hero hero--page hero--prog","anchor":"top","layout":{"type":"default"}} -->
<div id="top" class="wp-block-cover hero hero--page hero--prog" style="min-height:86vh"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background" alt="Marchers holding a We the People poster downtown" src="<?php echo raices_img( 'prog-6.webp' ); ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
<!-- wp:group {"className":"hero-copy","layout":{"type":"default"}} -->
<div class="wp-block-group hero-copy">
<!-- wp:paragraph {"className":"eyebrow mono"} -->
<p class="eyebrow mono"><span>Organizing</span></p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"className":"hero-title"} -->
<h1 class="wp-block-heading hero-title"><span class="line"><span>Stronger</span></span><span class="line"><span><em>together.</em></span></span></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"hero-lede"} -->
<p class="hero-lede">Tenants who know their rights and stand together keep their homes. We train them and back them up.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div></div>
<!-- /wp:cover -->
<!-- wp:html -->
<section class="pg pg--paper pg-first">
<div class="pg-inner pg-intro">
  <div>
    <p class="label mono">Who it's for</p>
    <p class="pg-who">Any renter in Cedar Hill, in any building, no matter who the landlord is.</p>
  </div>
  <aside class="pg-facts" aria-label="Tenant Organizing">
    <p class="label mono">Status</p>
    <p class="pg-status">Meets monthly</p>
    <dl>
      <div><dt class="mono">Meets</dt><dd>First Wednesday of the month, 6:30 PM</dd></div>
      <div><dt class="mono">Where</dt><dd>Calder Square community room</dd></div>
      <div><dt class="mono">Cost</dt><dd>Free, with dinner and childcare</dd></div>
    </dl>
  </aside>
</div>
</section>
<section class="pg pg--cream">
<div class="pg-inner">
  <p class="label mono">What you get</p>
  <h2 class="h-big">What you <em>get.</em></h2>
  <ul class="pg-gets">
    <li><span class="n mono">01</span><h3>Know your rights</h3><p>Workshops on leases, repairs, rent increases and eviction notices.</p></li>
    <li><span class="n mono">02</span><h3>Backup in court</h3><p>A trained advocate goes with you to housing court.</p></li>
    <li><span class="n mono">03</span><h3>A tenants' association</h3><p>Help organizing your building, so the landlord deals with all of you.</p></li>
    <li><span class="n mono">04</span><h3>Leadership training</h3><p>A ten-week course for tenants who want to lead.</p></li>
  </ul>
</div>
</section>
<section class="pg pg--paper">
<div class="pg-inner">
  <p class="label mono">Next meetings · 6:30 PM</p>
  <h2 class="h-big">See you <em>Wednesday.</em></h2>
  <ol class="pg-sched">
    <li><span class="d">Dec 2</span><span class="s">Heat and repairs: what your landlord owes you</span></li>
    <li><span class="d">Jan 6</span><span class="s">Rent increases and how to respond</span></li>
    <li><span class="d">Feb 3</span><span class="s">Starting a tenants' association</span></li>
    <li><span class="d">Mar 3</span><span class="s">Housing court, step by step</span></li>
  </ol>
</div>
</section>
<section class="pg pg--night" id="start">
<div class="pg-inner">
  <p class="label mono">How to start</p>
  <h2 class="h-big">Three <em>steps.</em></h2>
  <ol class="pg-steps">
    <li><span class="n" aria-hidden="true">1</span><h3>Come to a meeting</h3><p>The first Wednesday of every month. Bring a neighbor.</p></li>
    <li><span class="n" aria-hidden="true">2</span><h3>Tell us about your building</h3><p>An organizer will come by and listen.</p></li>
    <li><span class="n" aria-hidden="true">3</span><h3>Act together</h3><p>Letters, meetings with the landlord and, when needed, court.</p></li>
  </ol>
  <div class="pg-cta"><a class="btn btn-amber btn-xl" href="/contact/"><span>Come to the next meeting</span></a><p class="pg-call"><span>Or call</span> <a href="tel:+16175550142">617-555-0142</a></p></div>
</div>
</section>
<section class="pg pg--cream pg-last">
<div class="pg-inner">
  <p class="label mono">More programs</p>
  <h2 class="h-big">Help for <em>every chapter.</em></h2>
  <ul class="pg-more">
    <li><a href="/affordable-rentals/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-1.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Housing</span><b>Affordable Rentals</b><i>Waitlist open</i></a></li>
    <li><a href="/first-time-homebuyers/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-2.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Housing</span><b>First-Time Homebuyers</b><i>Spring class open</i></a></li>
    <li><a href="/career-coaching/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-3.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Jobs</span><b>Career Coaching</b><i>Open year-round</i></a></li>
    <li><a href="/free-tax-prep/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-4.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Money</span><b>Free Tax Prep</b><i>Opens Feb 1</i></a></li>
    <li><a href="/small-business-loans/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-5.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Business</span><b>Small Business Loans</b><i>Rolling — up to $50K</i></a></li>
  </ul>
</div>
</section>
<!-- /wp:html -->
