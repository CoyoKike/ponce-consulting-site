<?php
/**
 * Title: Program — Career Coaching
 * Slug: raices/program-career-coaching
 * Categories: raices
 */
?>
<!-- wp:cover {"url":"<?php echo raices_img( 'prog-3.webp' ); ?>","dimRatio":0,"minHeight":86,"minHeightUnit":"vh","className":"hero hero--page hero--prog","anchor":"top","layout":{"type":"default"}} -->
<div id="top" class="wp-block-cover hero hero--page hero--prog" style="min-height:86vh"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background" alt="A smiling woman in a yellow jacket talking with a group" src="<?php echo raices_img( 'prog-3.webp' ); ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
<!-- wp:group {"className":"hero-copy","layout":{"type":"default"}} -->
<div class="wp-block-group hero-copy">
<!-- wp:paragraph {"className":"eyebrow mono"} -->
<p class="eyebrow mono"><span>Jobs</span></p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"className":"hero-title"} -->
<h1 class="wp-block-heading hero-title"><span class="line"><span>Work that</span></span><span class="line"><span><em>pays.</em></span></span></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"hero-lede"} -->
<p class="hero-lede">A coach who helps you get hired, get a raise or switch fields, for as long as it takes.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div></div>
<!-- /wp:cover -->
<!-- wp:html -->
<section class="pg pg--paper pg-first">
<div class="pg-inner pg-intro">
  <div>
    <p class="label mono">Who it's for</p>
    <p class="pg-who">Anyone 18 or older who lives in or near Cedar Hill, working or not, with any amount of schooling.</p>
  </div>
  <aside class="pg-facts" aria-label="Career Coaching">
    <p class="label mono">Status</p>
    <p class="pg-status">Open year-round</p>
    <dl>
      <div><dt class="mono">Cost</dt><dd>Free</dd></div>
      <div><dt class="mono">Where</dt><dd>1200 Linden Street, 3rd floor, and by phone</dd></div>
      <div><dt class="mono">Hours</dt><dd>Monday to Thursday until 7 PM</dd></div>
    </dl>
  </aside>
</div>
</section>
<section class="pg pg--cream">
<div class="pg-inner">
  <p class="label mono">What you get</p>
  <h2 class="h-big">What you <em>get.</em></h2>
  <ul class="pg-gets">
    <li><span class="n mono">01</span><h3>A coach of your own</h3><p>The same person every time, from the first meeting to the first paycheck.</p></li>
    <li><span class="n mono">02</span><h3>Paid training</h3><p>Certificates in healthcare, building trades and IT, with a stipend while you learn.</p></li>
    <li><span class="n mono">03</span><h3>Résumés and interviews</h3><p>Practice runs with real hiring managers.</p></li>
    <li><span class="n mono">04</span><h3>Help with the extras</h3><p>Childcare, a T pass or work boots, so nothing gets in the way.</p></li>
  </ul>
</div>
</section>
<section class="pg pg--paper">
<div class="pg-inner">
  <p class="label mono">Training tracks</p>
  <h2 class="h-big">Where people <em>land.</em></h2>
  <div class="pg-scroll"><table class="pg-table">
    <thead><tr><th scope="col">Track</th><th scope="col">Length</th><th scope="col">Starting pay</th></tr></thead>
    <tbody>
      <tr><th scope="row">Certified Nursing Assistant</th><td>8 weeks</td><td>$22 an hour</td></tr>
      <tr><th scope="row">Medical Assistant</th><td>16 weeks</td><td>$24 an hour</td></tr>
      <tr><th scope="row">Building trades pre-apprenticeship</th><td>12 weeks</td><td>$26 an hour</td></tr>
      <tr><th scope="row">IT support (CompTIA A+)</th><td>14 weeks</td><td>$25 an hour</td></tr>
    </tbody>
  </table></div>
</div>
</section>
<section class="pg pg--night" id="start">
<div class="pg-inner">
  <p class="label mono">How to start</p>
  <h2 class="h-big">Three <em>steps.</em></h2>
  <ol class="pg-steps">
    <li><span class="n" aria-hidden="true">1</span><h3>Come to an info session</h3><p>Tuesdays at 6 PM or Thursdays at noon. No sign-up needed.</p></li>
    <li><span class="n" aria-hidden="true">2</span><h3>Meet your coach</h3><p>Talk through what you want and what's in the way.</p></li>
    <li><span class="n" aria-hidden="true">3</span><h3>Make a plan and start</h3><p>Training, applications or asking for a raise, whichever comes first.</p></li>
  </ol>
  <div class="pg-cta"><a class="btn btn-amber btn-xl" href="/contact/"><span>Meet a coach</span></a><p class="pg-call"><span>Or call</span> <a href="tel:+16175550142">617-555-0142</a></p></div>
</div>
</section>
<section class="pg pg--cream pg-last">
<div class="pg-inner">
  <p class="label mono">More programs</p>
  <h2 class="h-big">Help for <em>every chapter.</em></h2>
  <ul class="pg-more">
    <li><a href="/affordable-rentals/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-1.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Housing</span><b>Affordable Rentals</b><i>Waitlist open</i></a></li>
    <li><a href="/first-time-homebuyers/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-2.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Housing</span><b>First-Time Homebuyers</b><i>Spring class open</i></a></li>
    <li><a href="/free-tax-prep/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-4.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Money</span><b>Free Tax Prep</b><i>Opens Feb 1</i></a></li>
    <li><a href="/small-business-loans/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-5.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Business</span><b>Small Business Loans</b><i>Rolling — up to $50K</i></a></li>
    <li><a href="/tenant-organizing/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-6.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Organizing</span><b>Tenant Organizing</b><i>Meets monthly</i></a></li>
  </ul>
</div>
</section>
<!-- /wp:html -->
