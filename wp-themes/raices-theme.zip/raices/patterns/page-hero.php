<?php
/**
 * Title: Page hero (About)
 * Slug: raices/about-hero
 * Categories: raices
 */
?>
<!-- wp:cover {"url":"<?php echo raices_img( 'about-hero.webp' ); ?>","dimRatio":0,"minHeight":86,"minHeightUnit":"vh","className":"hero hero--page","anchor":"top","layout":{"type":"default"}} -->
<div id="top" class="wp-block-cover hero hero--page" style="min-height:86vh"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background" alt="Women in white and red dresses dancing in a neighborhood parade" src="<?php echo raices_img( 'about-hero.webp' ); ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
<!-- wp:group {"className":"hero-copy","layout":{"type":"default"}} -->
<div class="wp-block-group hero-copy">
<!-- wp:paragraph {"className":"eyebrow mono"} -->
<p class="eyebrow mono"><span>About Raíces</span></p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"className":"hero-title"} -->
<h1 class="wp-block-heading hero-title"><span class="line"><span>Neighbors</span></span><span class="line"><span><em>since 1981.</em></span></span></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"hero-lede"} -->
<p class="hero-lede">We started as twelve tenants on Linden Street who refused to be pushed out. Today we are 48 staff and 2,000 members.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div></div>
<!-- /wp:cover -->
