<?php
/**
 * Title: About — our story
 * Slug: raices/about-story
 * Categories: raices
 */
?>
<!-- wp:group {"tagName":"section","className":"statement story-sec","layout":{"type":"default"}} -->
<section class="wp-block-group statement story-sec">
<!-- wp:group {"className":"statement-inner","layout":{"type":"default"}} -->
<div class="wp-block-group statement-inner">
<!-- wp:paragraph {"className":"label mono"} -->
<p class="label mono">Our story</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"className":"h-big"} -->
<h2 class="wp-block-heading h-big">Forty years of <em>staying put.</em></h2>
<!-- /wp:heading -->

<!-- wp:html -->
<ol class="timeline">
  <li><span class="tl-year">1981</span><p>Twelve tenants on Linden Street organize against a mass eviction, <em>and win.</em></p></li>
  <li><span class="tl-year">1989</span><p>We buy and repair our first building: 24 homes that are <em>still affordable today.</em></p></li>
  <li><span class="tl-year">2004</span><p>Free tax prep opens in a church basement. Forty families come <em>the first year.</em></p></li>
  <li><span class="tl-year">2012</span><p>The small business fund makes its first loan, <em>to a bakery on Centre Street.</em></p></li>
  <li><span class="tl-year">2024</span><p>Our 1,100th affordable home opens <em>at Calder Square.</em></p></li>
</ol>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
