<?php
/**
 * Title: Hero
 * Slug: raices/hero
 * Categories: raices
 */
?>
<!-- wp:cover {"url":"<?php echo raices_img( 'hero.webp' ); ?>","dimRatio":0,"minHeight":100,"minHeightUnit":"vh","className":"hero","anchor":"top","layout":{"type":"default"}} -->
<div id="top" class="wp-block-cover hero" style="min-height:100vh"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background" alt="Neighbors in bright costumes dancing together in a closed-off city street" src="<?php echo raices_img( 'hero.webp' ); ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
<!-- wp:group {"className":"hero-copy","layout":{"type":"default"}} -->
<div class="wp-block-group hero-copy">
<!-- wp:paragraph {"className":"eyebrow mono"} -->
<p class="eyebrow mono"><span>Cedar Hill</span><span>Since 1981</span></p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"className":"hero-title"} -->
<h1 class="wp-block-heading hero-title"><span class="line"><span>Here</span></span><span class="line"><span><em>to stay.</em></span></span></h1>
<!-- /wp:heading -->

<!-- wp:group {"className":"hero-foot","layout":{"type":"default"}} -->
<div class="wp-block-group hero-foot">
<!-- wp:paragraph {"className":"hero-lede"} -->
<p class="hero-lede">Homes, jobs and small business help for the families of Cedar Hill.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<div class="hero-ctas"><a class="btn btn-light" href="#homes"><span>Find a home</span></a><a class="btn btn-ghost" href="#paths"><span>I'm looking for…</span></a></div>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div class="scroll-cue mono" aria-hidden="true"><span>Scroll</span><i></i></div>
<!-- /wp:html -->
</div></div>
<!-- /wp:cover -->
