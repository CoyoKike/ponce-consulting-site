<?php
/**
 * Title: Give
 * Slug: raices/give
 * Categories: raices
 */
?>
<!-- wp:group {"tagName":"section","className":"give","anchor":"give","layout":{"type":"default"}} -->
<section id="give" class="wp-block-group give">
<!-- wp:html -->
<div class="give-bg"><img src="<?php echo raices_img( 'give.webp' ); ?>" alt="" loading="lazy" decoding="async"></div>
<!-- /wp:html -->

<!-- wp:group {"className":"give-inner","layout":{"type":"default"}} -->
<div class="wp-block-group give-inner">
<!-- wp:paragraph {"className":"label mono"} -->
<p class="label mono">07 / Donate</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"className":"give-title"} -->
<h2 class="wp-block-heading give-title">Keep Cedar Hill <em>home.</em></h2>
<!-- /wp:heading -->

<!-- wp:html -->
<div class="give-grid">
  <form class="give-form" id="giveForm">
    <div class="amounts" role="radiogroup" aria-label="Gift amount">
      <button type="button" role="radio" aria-checked="false">$50</button>
      <button type="button" role="radio" aria-checked="true">$100</button>
      <button type="button" role="radio" aria-checked="false">$250</button>
      <button type="button" role="radio" aria-checked="false">$500</button>
    </div>
    <div class="freq" role="radiogroup" aria-label="Frequency"><button type="button" role="radio" aria-checked="false">Once</button><button type="button" role="radio" aria-checked="true">Monthly</button></div>
    <button class="btn btn-amber btn-xl" type="submit" id="giveBtn"><span>Give $100 monthly</span></button>
    <p class="form-note mono">Preview only. Nothing is charged.</p>
  </form>
  <ul class="give-more">
    <li><a href="#give"><span class="mono">Aug 16 · Linden Street</span><b>Fiesta de la Calle</b></a></li>
    <li><a href="#give"><span class="mono">Volunteer</span><b>Volunteer with us</b></a></li>
  </ul>
</div>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
