<?php
/**
 * Title: Program — Small Business Loans
 * Slug: raices/program-small-business-loans
 * Categories: raices
 */
?>
<!-- wp:cover {"url":"<?php echo raices_img( 'prog-5.webp' ); ?>","dimRatio":0,"minHeight":86,"minHeightUnit":"vh","className":"hero hero--page hero--prog","anchor":"top","layout":{"type":"default"}} -->
<div id="top" class="wp-block-cover hero hero--page hero--prog" style="min-height:86vh"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background" alt="A barber cutting a customer&#x27;s hair in his shop" src="<?php echo raices_img( 'prog-5.webp' ); ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
<!-- wp:group {"className":"hero-copy","layout":{"type":"default"}} -->
<div class="wp-block-group hero-copy">
<!-- wp:paragraph {"className":"eyebrow mono"} -->
<p class="eyebrow mono"><span>Business</span></p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"className":"hero-title"} -->
<h1 class="wp-block-heading hero-title"><span class="line"><span>Capital for</span></span><span class="line"><span><em>Main Street.</em></span></span></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"hero-lede"} -->
<p class="hero-lede">Loans and free advising for the shops, kitchens and trades that make Cedar Hill what it is.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div></div>
<!-- /wp:cover -->
<!-- wp:html -->
<section class="pg pg--paper pg-first">
<div class="pg-inner pg-intro">
  <div>
    <p class="label mono">Who it's for</p>
    <p class="pg-who">Businesses in and around Cedar Hill, from first idea to ten years in, including owners the banks turned away.</p>
  </div>
  <aside class="pg-facts" aria-label="Small Business Loans">
    <p class="label mono">Status</p>
    <p class="pg-status">Rolling — up to $50K</p>
    <dl>
      <div><dt class="mono">Loans</dt><dd>$1,000 to $50,000</dd></div>
      <div><dt class="mono">Decision</dt><dd>In about three weeks</dd></div>
      <div><dt class="mono">Advising</dt><dd>Free, in English and Spanish</dd></div>
    </dl>
  </aside>
</div>
</section>
<section class="pg pg--cream">
<div class="pg-inner">
  <p class="label mono">What you get</p>
  <h2 class="h-big">What you <em>get.</em></h2>
  <ul class="pg-gets">
    <li><span class="n mono">01</span><h3>Fair, fixed rates</h3><p>No prepayment penalties and no hidden fees.</p></li>
    <li><span class="n mono">02</span><h3>No minimum credit score</h3><p>We look at your business and your plan, not just a number.</p></li>
    <li><span class="n mono">03</span><h3>An advisor at the table</h3><p>Bookkeeping, pricing and permits, before and after the loan.</p></li>
    <li><span class="n mono">04</span><h3>Credit that counts</h3><p>We report on-time payments, so your next loan is easier.</p></li>
  </ul>
</div>
</section>
<section class="pg pg--paper">
<div class="pg-inner">
  <p class="label mono">Loan options</p>
  <h2 class="h-big">Pick a <em>size.</em></h2>
  <div class="pg-scroll"><table class="pg-table">
    <thead><tr><th scope="col">Loan</th><th scope="col">Amount</th><th scope="col">Rate</th><th scope="col">Term</th></tr></thead>
    <tbody>
      <tr><th scope="row">Starter</th><td>$1,000 – $10,000</td><td>6%</td><td>Up to 3 years</td></tr>
      <tr><th scope="row">Equipment</th><td>$5,000 – $35,000</td><td>7%</td><td>Up to 5 years</td></tr>
      <tr><th scope="row">Growth</th><td>$10,000 – $50,000</td><td>7.5%</td><td>Up to 6 years</td></tr>
    </tbody>
  </table></div>
</div>
</section>
<section class="pg pg--night" id="start">
<div class="pg-inner">
  <p class="label mono">How to start</p>
  <h2 class="h-big">Three <em>steps.</em></h2>
  <ol class="pg-steps">
    <li><span class="n" aria-hidden="true">1</span><h3>Talk to a lender</h3><p>A free 30-minute call with our lending team.</p></li>
    <li><span class="n" aria-hidden="true">2</span><h3>Send your numbers</h3><p>Bank statements and a simple plan. We'll help you write it.</p></li>
    <li><span class="n" aria-hidden="true">3</span><h3>Get a decision</h3><p>Most loans close in about three weeks.</p></li>
  </ol>
  <div class="pg-cta"><a class="btn btn-amber btn-xl" href="/contact/"><span>Talk to a lender</span></a><p class="pg-call"><span>Or call</span> <a href="tel:+16175550142">617-555-0142</a></p></div>
</div>
</section>
<section class="pg pg--cream pg-last">
<div class="pg-inner">
  <p class="label mono">More programs</p>
  <h2 class="h-big">Help for <em>every chapter.</em></h2>
  <ul class="pg-more">
    <li><a href="/affordable-rentals/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-1.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Housing</span><b>Affordable Rentals</b><i>Waitlist open</i></a></li>
    <li><a href="/first-time-homebuyers/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-2.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Housing</span><b>First-Time Homebuyers</b><i>Spring class open</i></a></li>
    <li><a href="/career-coaching/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-3.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Jobs</span><b>Career Coaching</b><i>Open year-round</i></a></li>
    <li><a href="/free-tax-prep/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-4.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Money</span><b>Free Tax Prep</b><i>Opens Feb 1</i></a></li>
    <li><a href="/tenant-organizing/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-6.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Organizing</span><b>Tenant Organizing</b><i>Meets monthly</i></a></li>
  </ul>
</div>
</section>
<!-- /wp:html -->
