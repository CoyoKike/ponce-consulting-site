<?php
/**
 * Title: Program — First-Time Homebuyers
 * Slug: raices/program-first-time-homebuyers
 * Categories: raices
 */
?>
<!-- wp:cover {"url":"<?php echo raices_img( 'prog-2.webp' ); ?>","dimRatio":0,"minHeight":86,"minHeightUnit":"vh","className":"hero hero--page hero--prog","anchor":"top","layout":{"type":"default"}} -->
<div id="top" class="wp-block-cover hero hero--page hero--prog" style="min-height:86vh"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background" alt="A purple front door in an old stone wall" src="<?php echo raices_img( 'prog-2.webp' ); ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
<!-- wp:group {"className":"hero-copy","layout":{"type":"default"}} -->
<div class="wp-block-group hero-copy">
<!-- wp:paragraph {"className":"eyebrow mono"} -->
<p class="eyebrow mono"><span>Housing</span></p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"className":"hero-title"} -->
<h1 class="wp-block-heading hero-title"><span class="line"><span>Your own</span></span><span class="line"><span><em>front door.</em></span></span></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"hero-lede"} -->
<p class="hero-lede">A six-week class, a counselor who stays with you, and help with the down payment.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div></div>
<!-- /wp:cover -->
<!-- wp:html -->
<section class="pg pg--paper pg-first">
<div class="pg-inner pg-intro">
  <div>
    <p class="label mono">Who it's for</p>
    <p class="pg-who">First-time buyers, or anyone who hasn't owned a home in three years, with a steady income and a plan to buy within two years.</p>
  </div>
  <aside class="pg-facts" aria-label="First-Time Homebuyers">
    <p class="label mono">Status</p>
    <p class="pg-status">Spring class open</p>
    <dl>
      <div><dt class="mono">Cost</dt><dd>$50 for the full class, waived on request</dd></div>
      <div><dt class="mono">Where</dt><dd>Saturdays at 1200 Linden Street, or on Zoom</dd></div>
      <div><dt class="mono">Languages</dt><dd>English and Spanish</dd></div>
    </dl>
  </aside>
</div>
</section>
<section class="pg pg--cream">
<div class="pg-inner">
  <p class="label mono">What you get</p>
  <h2 class="h-big">What you <em>get.</em></h2>
  <ul class="pg-gets">
    <li><span class="n mono">01</span><h3>A certificate lenders accept</h3><p>Required for MassHousing and most first-time buyer loans.</p></li>
    <li><span class="n mono">02</span><h3>Down payment help</h3><p>Grants up to $25,000 for graduates buying in Cedar Hill.</p></li>
    <li><span class="n mono">03</span><h3>A counselor, one on one</h3><p>Credit, budget and loan offers, reviewed with you until closing.</p></li>
    <li><span class="n mono">04</span><h3>Homes before they list</h3><p>Graduates hear first when Raíces sells a home.</p></li>
  </ul>
</div>
</section>
<section class="pg pg--paper">
<div class="pg-inner">
  <p class="label mono">Spring class · 10 AM to 1 PM</p>
  <h2 class="h-big">Six <em>Saturdays.</em></h2>
  <ol class="pg-sched">
    <li><span class="d">Mar 6</span><span class="s">Is buying right for you?</span></li>
    <li><span class="d">Mar 13</span><span class="s">Credit and budgets</span></li>
    <li><span class="d">Mar 20</span><span class="s">Getting a mortgage</span></li>
    <li><span class="d">Mar 27</span><span class="s">Finding a home and making an offer</span></li>
    <li><span class="d">Apr 3</span><span class="s">Inspections and closing</span></li>
    <li><span class="d">Apr 10</span><span class="s">Keeping your home</span></li>
  </ol>
</div>
</section>
<section class="pg pg--night" id="start">
<div class="pg-inner">
  <p class="label mono">How to start</p>
  <h2 class="h-big">Three <em>steps.</em></h2>
  <ol class="pg-steps">
    <li><span class="n" aria-hidden="true">1</span><h3>Save a seat</h3><p>Online or by phone. Classes fill about three weeks ahead.</p></li>
    <li><span class="n" aria-hidden="true">2</span><h3>Meet your counselor</h3><p>One hour to look at your credit and savings together.</p></li>
    <li><span class="n" aria-hidden="true">3</span><h3>Graduate and get pre-approved</h3><p>We introduce you to lenders who know our grants.</p></li>
  </ol>
  <div class="pg-cta"><a class="btn btn-amber btn-xl" href="/contact/"><span>Save a seat</span></a><p class="pg-call"><span>Or call</span> <a href="tel:+16175550142">617-555-0142</a></p></div>
</div>
</section>
<section class="pg pg--cream pg-last">
<div class="pg-inner">
  <p class="label mono">More programs</p>
  <h2 class="h-big">Help for <em>every chapter.</em></h2>
  <ul class="pg-more">
    <li><a href="/affordable-rentals/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-1.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Housing</span><b>Affordable Rentals</b><i>Waitlist open</i></a></li>
    <li><a href="/career-coaching/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-3.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Jobs</span><b>Career Coaching</b><i>Open year-round</i></a></li>
    <li><a href="/free-tax-prep/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-4.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Money</span><b>Free Tax Prep</b><i>Opens Feb 1</i></a></li>
    <li><a href="/small-business-loans/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-5.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Business</span><b>Small Business Loans</b><i>Rolling — up to $50K</i></a></li>
    <li><a href="/tenant-organizing/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-6.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Organizing</span><b>Tenant Organizing</b><i>Meets monthly</i></a></li>
  </ul>
</div>
</section>
<!-- /wp:html -->
