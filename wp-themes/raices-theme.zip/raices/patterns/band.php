<?php
/**
 * Title: Neighbor quote
 * Slug: raices/band
 * Categories: raices
 */
?>
<!-- wp:cover {"url":"<?php echo raices_img( 'band.webp' ); ?>","dimRatio":0,"className":"band","layout":{"type":"default"}} -->
<div class="wp-block-cover band"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background" alt="A grocer giving a thumbs up behind his counter" src="<?php echo raices_img( 'band.webp' ); ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
<!-- wp:group {"tagName":"blockquote","className":"band-quote","layout":{"type":"default"}} -->
<blockquote class="wp-block-group band-quote">
<!-- wp:paragraph -->
<p>“No bank would look at me. <em>Raíces did.”</em></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"mono"} -->
<p class="mono">Héctor Ramírez · Ramírez Market · Linden Street</p>
<!-- /wp:paragraph -->
</blockquote>
<!-- /wp:group -->
</div></div>
<!-- /wp:cover -->
