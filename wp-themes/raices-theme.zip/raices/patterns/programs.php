<?php
/**
 * Title: Programs carousel
 * Slug: raices/programs
 * Categories: raices
 */
?>
<!-- wp:group {"tagName":"section","className":"work","anchor":"programs","layout":{"type":"default"}} -->
<section id="programs" class="wp-block-group work">
<!-- wp:group {"className":"work-head","layout":{"type":"default"}} -->
<div class="wp-block-group work-head">
<!-- wp:paragraph {"className":"label mono"} -->
<p class="label mono">02 / Programs</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"className":"h-big"} -->
<h2 class="wp-block-heading h-big">Help for <em>every chapter.</em></h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div class="car" role="region" aria-roledescription="carousel" aria-label="Programs">
  <div class="car-track" id="workTrack" tabindex="0">
    <article class="card slide"><div class="card-media"><img src="<?php echo raices_img( 'prog-1.webp' ); ?>" alt="A yellow apartment building with balconies and flower boxes" loading="lazy" decoding="async"></div>
      <div class="card-body"><span class="mono">Housing</span><h3>Affordable Rentals</h3><p class="status">Waitlist open</p><a class="more mono" href="#homes">See buildings →</a></div></article>
    <article class="card slide"><div class="card-media"><img src="<?php echo raices_img( 'prog-2.webp' ); ?>" alt="A young couple sitting among moving boxes in their first home" loading="lazy" decoding="async"></div>
      <div class="card-body"><span class="mono">Housing</span><h3>First-Time Homebuyers</h3><p class="status">Spring class open</p><a class="more mono" href="#programs">Save a seat →</a></div></article>
    <article class="card slide"><div class="card-media"><img src="<?php echo raices_img( 'prog-3.webp' ); ?>" alt="A career coach meeting with a client by the window" loading="lazy" decoding="async"></div>
      <div class="card-body"><span class="mono">Jobs</span><h3>Career Coaching</h3><p class="status">Open year-round</p><a class="more mono" href="#programs">Meet a coach →</a></div></article>
    <article class="card slide"><div class="card-media"><img src="<?php echo raices_img( 'prog-4.webp' ); ?>" alt="A woman working through her budget with a notebook and phone" loading="lazy" decoding="async"></div>
      <div class="card-body"><span class="mono">Money</span><h3>Free Tax Prep</h3><p class="status">Opens Feb 1</p><a class="more mono" href="#programs">Book a time →</a></div></article>
    <article class="card slide"><div class="card-media"><img src="<?php echo raices_img( 'prog-5.webp' ); ?>" alt="A young shop owner sitting in front of his store counter" loading="lazy" decoding="async"></div>
      <div class="card-body"><span class="mono">Business</span><h3>Small Business Loans</h3><p class="status">Rolling — up to $50K</p><a class="more mono" href="#programs">Check rates →</a></div></article>
    <article class="card slide"><div class="card-media"><img src="<?php echo raices_img( 'prog-6.webp' ); ?>" alt="Neighbors at a rally with signs and flags" loading="lazy" decoding="async"></div>
      <div class="card-body"><span class="mono">Organizing</span><h3>Tenant Organizing</h3><p class="status">Meets monthly</p><a class="more mono" href="#news">Next meeting →</a></div></article>
  </div>
  <div class="car-ui">
    <div class="car-bar" aria-hidden="true"><i id="carBar"></i></div>
    <span class="car-count mono" aria-live="polite"><b id="carNow">01</b> / 06</span>
    <button class="car-btn" id="carPrev" aria-label="Previous programs"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M15 5l-7 7 7 7"/></svg></button>
    <button class="car-btn" id="carNext" aria-label="Next programs"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M9 5l7 7-7 7"/></svg></button>
  </div>
</div>
<!-- /wp:html -->
</section>
<!-- /wp:group -->
