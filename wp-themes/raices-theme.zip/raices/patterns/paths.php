<?php
/**
 * Title: I'm looking for
 * Slug: raices/paths
 * Categories: raices
 */
?>
<!-- wp:group {"tagName":"section","className":"paths","anchor":"paths","layout":{"type":"default"}} -->
<section id="paths" class="wp-block-group paths">
<!-- wp:group {"className":"paths-head","layout":{"type":"default"}} -->
<div class="wp-block-group paths-head">
<!-- wp:paragraph {"className":"label mono"} -->
<p class="label mono">02 / Get help</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"className":"h-big"} -->
<h2 class="wp-block-heading h-big">I'm looking <em>for…</em></h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<ul class="path-list" id="pathList">
  <li><a href="#homes" data-img="<?php echo raices_img( 'path-1.webp' ); ?>"><img class="thumb" src="<?php echo raices_img( 'path-1.webp' ); ?>" alt="" loading="lazy"><span class="mono">01</span><h3>An affordable home</h3></a></li>
  <li><a href="#programs" data-img="<?php echo raices_img( 'path-2.webp' ); ?>"><img class="thumb" src="<?php echo raices_img( 'path-2.webp' ); ?>" alt="" loading="lazy"><span class="mono">02</span><h3>A better job</h3></a></li>
  <li><a href="#programs" data-img="<?php echo raices_img( 'path-3.webp' ); ?>"><img class="thumb" src="<?php echo raices_img( 'path-3.webp' ); ?>" alt="" loading="lazy"><span class="mono">03</span><h3>Help with money</h3></a></li>
  <li><a href="#programs" data-img="<?php echo raices_img( 'path-4.webp' ); ?>"><img class="thumb" src="<?php echo raices_img( 'path-4.webp' ); ?>" alt="" loading="lazy"><span class="mono">04</span><h3>Support for my business</h3></a></li>
</ul>
<div class="path-peek" id="pathPeek" aria-hidden="true"><img alt=""></div>
<!-- /wp:html -->
</section>
<!-- /wp:group -->
