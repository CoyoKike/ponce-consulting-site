<?php
/**
 * Title: Impact
 * Slug: raices/impact
 * Categories: raices
 */
?>
<!-- wp:group {"tagName":"section","className":"impact","anchor":"impact","layout":{"type":"default"}} -->
<section id="impact" class="wp-block-group impact">
<!-- wp:paragraph {"className":"label mono"} -->
<p class="label mono">Since 1981</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<div class="stats">
  <div><b data-n="1100">1,100</b><span class="mono">Affordable homes built and kept</span></div>
  <div><b data-n="3400">3,400</b><span class="mono">Families coached last year</span></div>
  <div class="money"><b data-n="12">12</b><span class="mono">Million in tax refunds returned</span></div>
  <div><b data-n="210">210</b><span class="mono">Local businesses backed</span></div>
</div>
<!-- /wp:html -->
</section>
<!-- /wp:group -->
