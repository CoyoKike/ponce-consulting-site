<?php
/**
 * Title: Program — Affordable Rentals
 * Slug: raices/program-affordable-rentals
 * Categories: raices
 */
?>
<!-- wp:cover {"url":"<?php echo raices_img( 'prog-1.webp' ); ?>","dimRatio":0,"minHeight":86,"minHeightUnit":"vh","className":"hero hero--page hero--prog","anchor":"top","layout":{"type":"default"}} -->
<div id="top" class="wp-block-cover hero hero--page hero--prog" style="min-height:86vh"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background" alt="Brick row houses with front porches and gardens" src="<?php echo raices_img( 'prog-1.webp' ); ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
<!-- wp:group {"className":"hero-copy","layout":{"type":"default"}} -->
<div class="wp-block-group hero-copy">
<!-- wp:paragraph {"className":"eyebrow mono"} -->
<p class="eyebrow mono"><span>Housing</span></p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"className":"hero-title"} -->
<h1 class="wp-block-heading hero-title"><span class="line"><span>Rent that</span></span><span class="line"><span><em>stays put.</em></span></span></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"hero-lede"} -->
<p class="hero-lede">1,100 apartments across Cedar Hill, priced for the families who live here and kept that way for good.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div></div>
<!-- /wp:cover -->
<!-- wp:html -->
<section class="pg pg--paper pg-first">
<div class="pg-inner pg-intro">
  <div>
    <p class="label mono">Who it's for</p>
    <p class="pg-who">Households earning up to 80% of the area median income who live or work in Cedar Hill, or want to come back.</p>
  </div>
  <aside class="pg-facts" aria-label="Affordable Rentals">
    <p class="label mono">Status</p>
    <p class="pg-status">Waitlist open</p>
    <dl>
      <div><dt class="mono">Rent</dt><dd>About 30% of what you earn</dd></div>
      <div><dt class="mono">Apply</dt><dd>1200 Linden Street, or by phone</dd></div>
      <div><dt class="mono">Typical wait</dt><dd>6 to 18 months, by apartment size</dd></div>
    </dl>
  </aside>
</div>
</section>
<section class="pg pg--cream">
<div class="pg-inner">
  <p class="label mono">What you get</p>
  <h2 class="h-big">What you <em>get.</em></h2>
  <ul class="pg-gets">
    <li><span class="n mono">01</span><h3>Rent tied to income</h3><p>Most families pay about a third of what they earn, never market rate.</p></li>
    <li><span class="n mono">02</span><h3>Repairs that happen</h3><p>A maintenance line that picks up, run by staff who live nearby.</p></li>
    <li><span class="n mono">03</span><h3>A lease that renews</h3><p>No one is moved out to raise the rent.</p></li>
    <li><span class="n mono">04</span><h3>A path to owning</h3><p>Our renters get the first seats in the homebuyer class.</p></li>
  </ul>
</div>
</section>
<section class="pg pg--paper">
<div class="pg-inner">
  <p class="label mono">2026 income limits</p>
  <h2 class="h-big">Who <em>qualifies.</em></h2>
  <div class="pg-scroll"><table class="pg-table">
    <thead><tr><th scope="col">Household size</th><th scope="col">30% AMI</th><th scope="col">60% AMI</th><th scope="col">80% AMI</th></tr></thead>
    <tbody>
      <tr><th scope="row">1 person</th><td>$34,000</td><td>$68,000</td><td>$90,650</td></tr>
      <tr><th scope="row">2 people</th><td>$38,850</td><td>$77,700</td><td>$103,600</td></tr>
      <tr><th scope="row">3 people</th><td>$43,700</td><td>$87,400</td><td>$116,550</td></tr>
      <tr><th scope="row">4 people</th><td>$48,550</td><td>$97,100</td><td>$129,450</td></tr>
    </tbody>
  </table></div>
</div>
</section>
<section class="pg pg--night" id="start">
<div class="pg-inner">
  <p class="label mono">How to start</p>
  <h2 class="h-big">Three <em>steps.</em></h2>
  <ol class="pg-steps">
    <li><span class="n" aria-hidden="true">1</span><h3>Fill out one application</h3><p>It covers every Raíces building, so you only apply once.</p></li>
    <li><span class="n" aria-hidden="true">2</span><h3>Bring proof of income</h3><p>Two recent pay stubs or a benefits letter. We make the copies.</p></li>
    <li><span class="n" aria-hidden="true">3</span><h3>Hear back by text and mail</h3><p>Every 90 days we tell you where you are on the list.</p></li>
  </ol>
  <div class="pg-cta"><a class="btn btn-amber btn-xl" href="/contact/"><span>Join the waitlist</span></a><a class="btn btn-ghost" href="/#homes"><span>See buildings</span></a><p class="pg-call"><span>Or call</span> <a href="tel:+16175550142">617-555-0142</a></p></div>
</div>
</section>
<section class="pg pg--cream pg-last">
<div class="pg-inner">
  <p class="label mono">More programs</p>
  <h2 class="h-big">Help for <em>every chapter.</em></h2>
  <ul class="pg-more">
    <li><a href="/first-time-homebuyers/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-2.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Housing</span><b>First-Time Homebuyers</b><i>Spring class open</i></a></li>
    <li><a href="/career-coaching/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-3.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Jobs</span><b>Career Coaching</b><i>Open year-round</i></a></li>
    <li><a href="/free-tax-prep/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-4.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Money</span><b>Free Tax Prep</b><i>Opens Feb 1</i></a></li>
    <li><a href="/small-business-loans/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-5.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Business</span><b>Small Business Loans</b><i>Rolling — up to $50K</i></a></li>
    <li><a href="/tenant-organizing/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-6.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Organizing</span><b>Tenant Organizing</b><i>Meets monthly</i></a></li>
  </ul>
</div>
</section>
<!-- /wp:html -->
