<?php
/**
 * Title: Program — Free Tax Prep
 * Slug: raices/program-free-tax-prep
 * Categories: raices
 */
?>
<!-- wp:cover {"url":"<?php echo raices_img( 'prog-4.webp' ); ?>","dimRatio":0,"minHeight":86,"minHeightUnit":"vh","className":"hero hero--page hero--prog","anchor":"top","layout":{"type":"default"}} -->
<div id="top" class="wp-block-cover hero hero--page hero--prog" style="min-height:86vh"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background" alt="Hands working through paperwork with a calculator" src="<?php echo raices_img( 'prog-4.webp' ); ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
<!-- wp:group {"className":"hero-copy","layout":{"type":"default"}} -->
<div class="wp-block-group hero-copy">
<!-- wp:paragraph {"className":"eyebrow mono"} -->
<p class="eyebrow mono"><span>Money</span></p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"className":"hero-title"} -->
<h1 class="wp-block-heading hero-title"><span class="line"><span>Keep your</span></span><span class="line"><span><em>refund.</em></span></span></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"hero-lede"} -->
<p class="hero-lede">IRS-certified volunteers file your taxes for free, so the whole refund stays with your family.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div></div>
<!-- /wp:cover -->
<!-- wp:html -->
<section class="pg pg--paper pg-first">
<div class="pg-inner pg-intro">
  <div>
    <p class="label mono">Who it's for</p>
    <p class="pg-who">Households earning under $68,000 a year, including self-employed workers and people who file with an ITIN.</p>
  </div>
  <aside class="pg-facts" aria-label="Free Tax Prep">
    <p class="label mono">Status</p>
    <p class="pg-status">Opens Feb 1</p>
    <dl>
      <div><dt class="mono">Cost</dt><dd>Free</dd></div>
      <div><dt class="mono">Season</dt><dd>February 1 to April 15</dd></div>
      <div><dt class="mono">Where</dt><dd>1200 Linden Street and the Centre Street library</dd></div>
    </dl>
  </aside>
</div>
</section>
<section class="pg pg--cream">
<div class="pg-inner">
  <p class="label mono">What you get</p>
  <h2 class="h-big">What you <em>get.</em></h2>
  <ul class="pg-gets">
    <li><span class="n mono">01</span><h3>Federal and state, both free</h3><p>No fees taken out of your refund.</p></li>
    <li><span class="n mono">02</span><h3>Every credit you've earned</h3><p>We check for the Earned Income and Child Tax Credits every time.</p></li>
    <li><span class="n mono">03</span><h3>Sit down or drop off</h3><p>Work with a preparer, or leave your papers and come back.</p></li>
    <li><span class="n mono">04</span><h3>Help after you file</h3><p>Got a letter from the IRS? Bring it in, any time of year.</p></li>
  </ul>
</div>
</section>
<section class="pg pg--paper">
<div class="pg-inner">
  <p class="label mono">What to bring</p>
  <h2 class="h-big">Bring <em>these.</em></h2>
  <ul class="pg-check">
    <li>Photo ID for you and your spouse</li>
    <li>Social Security cards or ITIN letters for everyone on the return</li>
    <li>W-2s, 1099s and any other income forms</li>
    <li>Form 1095-A if you have Health Connector insurance</li>
    <li>Childcare costs and your provider's tax ID</li>
    <li>Last year's return, if you have it</li>
    <li>A blank check for direct deposit</li>
  </ul>
</div>
</section>
<section class="pg pg--night" id="start">
<div class="pg-inner">
  <p class="label mono">How to start</p>
  <h2 class="h-big">Three <em>steps.</em></h2>
  <ol class="pg-steps">
    <li><span class="n" aria-hidden="true">1</span><h3>Book a time</h3><p>Appointments open January 15, online and by phone.</p></li>
    <li><span class="n" aria-hidden="true">2</span><h3>Bring your papers</h3><p>Use the list above. Missing something? We'll tell you what.</p></li>
    <li><span class="n" aria-hidden="true">3</span><h3>Sign and get paid</h3><p>Refunds usually arrive in two to three weeks by direct deposit.</p></li>
  </ol>
  <div class="pg-cta"><a class="btn btn-amber btn-xl" href="/contact/"><span>Book a time</span></a><p class="pg-call"><span>Or call</span> <a href="tel:+16175550142">617-555-0142</a></p></div>
</div>
</section>
<section class="pg pg--cream pg-last">
<div class="pg-inner">
  <p class="label mono">More programs</p>
  <h2 class="h-big">Help for <em>every chapter.</em></h2>
  <ul class="pg-more">
    <li><a href="/affordable-rentals/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-1.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Housing</span><b>Affordable Rentals</b><i>Waitlist open</i></a></li>
    <li><a href="/first-time-homebuyers/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-2.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Housing</span><b>First-Time Homebuyers</b><i>Spring class open</i></a></li>
    <li><a href="/career-coaching/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-3.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Jobs</span><b>Career Coaching</b><i>Open year-round</i></a></li>
    <li><a href="/small-business-loans/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-5.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Business</span><b>Small Business Loans</b><i>Rolling — up to $50K</i></a></li>
    <li><a href="/tenant-organizing/"><span class="pm-pic"><img src="<?php echo raices_img( 'prog-6.webp' ); ?>" alt="" loading="lazy" decoding="async"></span><span class="mono">Organizing</span><b>Tenant Organizing</b><i>Meets monthly</i></a></li>
  </ul>
</div>
</section>
<!-- /wp:html -->
