<?php
/**
 * Title: Our work (four programs)
 * Slug: raices/work
 * Categories: raices
 */
$rows = array(
	array( 'housing', 'work-housing.webp', 'Affordable housing', 'Homes people <em>can afford.</em>', 'We build, own and manage 1,100 affordable apartments, and help first-time buyers get their keys.', array( 'Apartments and waitlists', 'First-time homebuyer classes', 'Foreclosure and eviction help' ), 'A new affordable apartment building with balconies' ),
	array( 'prosperity', 'work-prosperity.webp', 'Family prosperity', 'Steady work, <em>growing savings.</em>', 'One-on-one coaches help families find better jobs, file taxes for free, build credit and save for what matters.', array( 'Career coaching and job placement', 'Free tax preparation', 'Financial and credit coaching' ), 'A coach shaking hands with a client after a meeting' ),
	array( 'business', 'work-business.webp', 'Small business', 'Keep our corners <em>open.</em>', 'Coaching, small loans and help with permits, marketing and leases for the shops that make Cedar Hill feel like home.', array( 'Business coaching in English and Spanish', 'Microloans up to $50,000', 'Storefront and lease support' ), 'A shop owner smiling among the spices and goods in his store' ),
	array( 'organizing', 'work-organizing.webp', 'Community organizing', 'A neighborhood <em>with a voice.</em>', 'Residents lead campaigns for fair rents, safe streets and good jobs, and we train the next generation of leaders.', array( 'Tenant associations', 'Leadership training', 'Community meetings every month' ), 'Neighbors marching together with signs at a community rally' ),
);
?>
<!-- wp:group {"tagName":"section","className":"r-work","layout":{"type":"constrained","contentSize":"1440px"}} -->
<section class="wp-block-group r-work">
<!-- wp:paragraph {"className":"r-label"} -->
<p class="r-label">What we do</p>
<!-- /wp:paragraph -->
<?php foreach ( $rows as $i => $r ) : ?>
<!-- wp:columns {"className":"r-row<?php echo $i % 2 ? ' r-row--flip' : ''; ?>","anchor":"<?php echo $r[0]; ?>"} -->
<div id="<?php echo $r[0]; ?>" class="wp-block-columns r-row<?php echo $i % 2 ? ' r-row--flip' : ''; ?>"><!-- wp:column {"width":"56%","className":"r-row-media"} -->
<div class="wp-block-column r-row-media" style="flex-basis:56%"><!-- wp:image -->
<figure class="wp-block-image"><img src="<?php echo raices_img( $r[1] ); ?>" alt="<?php echo esc_attr( $r[7] ); ?>"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"r-row-copy"} -->
<div class="wp-block-column r-row-copy"><!-- wp:paragraph {"className":"r-kicker"} -->
<p class="r-kicker"><?php echo esc_html( $r[2] ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:heading {"className":"r-h3"} -->
<h2 class="wp-block-heading r-h3"><?php echo wp_kses_post( $r[3] ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php echo esc_html( $r[4] ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:list {"className":"r-ticks"} -->
<ul class="wp-block-list r-ticks"><?php foreach ( $r[5] as $li ) : ?><!-- wp:list-item -->
<li><?php echo esc_html( $li ); ?></li>
<!-- /wp:list-item --><?php endforeach; ?></ul>
<!-- /wp:list -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"r-btn--forest"} -->
<div class="wp-block-button r-btn--forest"><a class="wp-block-button__link wp-element-button" href="#help">Learn more</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->
<?php endforeach; ?>
</section>
<!-- /wp:group -->
