<?php
/**
 * Title: Homes and waitlists
 * Slug: raices/homes
 * Categories: raices
 */
$homes = array(
	array( 'Linden Street Commons', 'Cedar Hill', '1–3 bedrooms', 'Up to 60% AMI', 'open', 'Waitlist open' ),
	array( 'Calder Square', 'Cedar Hill', 'Studios, 1 bedroom', 'Seniors 62+', 'open', 'Applying now' ),
	array( 'Juniper Gardens', 'Elm Park', '2–3 bedrooms', 'Up to 80% AMI', 'soon', 'Lottery opens Mar 3' ),
	array( 'Willow Street Homes', 'Cedar Hill', 'Homeownership', 'Up to 100% AMI', 'soon', 'Info session Feb 12' ),
	array( 'Ridgeview Lofts', 'Ridgeview', '1–2 bedrooms', 'Up to 50% AMI', 'closed', 'Waitlist closed' ),
);
?>
<!-- wp:group {"tagName":"section","className":"r-homes","anchor":"homes","layout":{"type":"constrained","contentSize":"1240px"}} -->
<section id="homes" class="wp-block-group r-homes">
<!-- wp:paragraph {"className":"r-label"} -->
<p class="r-label">Homes &amp; waitlists</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"className":"r-h2"} -->
<h2 class="wp-block-heading r-h2">Find a home <em>you can afford.</em></h2>
<!-- /wp:heading -->

<!-- wp:html -->
<div class="r-homes-tools">
  <label class="r-sr" for="r-homes-q">Search homes</label>
  <input id="r-homes-q" type="search" placeholder="Search by building or neighborhood">
  <label class="r-check"><input type="checkbox" id="r-homes-open"> Only show open</label>
</div>
<ul class="r-homes-list" id="r-homes-list">
<?php foreach ( $homes as $h ) : ?>
  <li data-status="<?php echo esc_attr( $h[4] ); ?>"><div><h3><?php echo esc_html( $h[0] ); ?></h3><p><?php echo esc_html( $h[1] ); ?></p></div><span><?php echo esc_html( $h[2] ); ?></span><span><?php echo esc_html( $h[3] ); ?></span><span class="r-chip r-chip--<?php echo esc_attr( $h[4] ); ?>"><?php echo esc_html( $h[5] ); ?></span><a href="#homes" aria-label="Details for <?php echo esc_attr( $h[0] ); ?>">Details →</a></li>
<?php endforeach; ?>
</ul>
<p class="r-homes-note">AMI means Area Median Income. Not sure if you qualify? <a href="#help">Talk to a housing counselor</a>.</p>
<!-- /wp:html -->
</section>
<!-- /wp:group -->
