<?php
/**
 * Title: Impact numbers
 * Slug: raices/impact
 * Categories: raices
 */
$stats = array( array( '1100', 'affordable homes built and managed' ), array( '3400', 'families coached this year' ), array( '2.4', 'million dollars in tax refunds returned' ), array( '210', 'small businesses supported' ) );
?>
<!-- wp:group {"tagName":"section","className":"r-impact","layout":{"type":"constrained","contentSize":"1440px"}} -->
<section class="wp-block-group r-impact">
<!-- wp:heading {"className":"r-h2"} -->
<h2 class="wp-block-heading r-h2">Last year, <em>together.</em></h2>
<!-- /wp:heading -->

<!-- wp:group {"className":"r-stats","layout":{"type":"grid","columnCount":4}} -->
<div class="wp-block-group r-stats">
<?php foreach ( $stats as $s ) : ?>
<!-- wp:group {"className":"r-stat","layout":{"type":"default"}} -->
<div class="wp-block-group r-stat"><!-- wp:paragraph {"className":"r-stat-n"} -->
<p class="r-stat-n" data-n="<?php echo esc_attr( $s[0] ); ?>"><?php echo esc_html( $s[0] === '2.4' ? '$2.4M' : number_format( (float) $s[0] ) ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><?php echo esc_html( $s[1] ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
<?php endforeach; ?>
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
