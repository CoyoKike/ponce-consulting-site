<?php
/**
 * Title: Resident story
 * Slug: raices/story
 * Categories: raices
 */
?>
<!-- wp:group {"tagName":"section","className":"r-story","layout":{"type":"constrained","contentSize":"1440px"}} -->
<section class="wp-block-group r-story">
<!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"46%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:46%"><!-- wp:image {"className":"r-story-img"} -->
<figure class="wp-block-image r-story-img"><img src="<?php echo raices_img( 'story.webp' ); ?>" alt="Rosa Martínez laughing with her young daughter in a park"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:paragraph {"className":"r-label"} -->
<p class="r-label">Neighbor stories</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"r-quote"} -->
<p class="r-quote">“When the rent doubled, I thought we would have to leave. Raíces found us an apartment two blocks away. My daughter <em>never had to change schools.</em>”</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"r-quote-name"} -->
<p class="r-quote-name">Rosa Martínez · Linden Street Commons resident</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->
</section>
<!-- /wp:group -->
