<?php
/**
 * Title: How can we help
 * Slug: raices/help
 * Categories: raices
 */
$tiles = array(
	array( 'help-housing.webp', 'I need an affordable home', 'Apartments, waitlists and first-time homebuyer classes.', '#homes', 'A smiling family standing together outside their home' ),
	array( 'help-coaching.webp', 'I want a better job', 'Free career coaching, training and job placement.', '#prosperity', 'A career coach meeting with a job seeker' ),
	array( 'help-money.webp', 'I need help with money or taxes', 'Free tax preparation, credit building and budgeting.', '#prosperity', 'A woman reviewing her family budget at the kitchen table' ),
	array( 'help-business.webp', 'I run a small business', 'Coaching, small loans and help with permits and marketing.', '#business', 'A smiling vendor at her fruit and vegetable market' ),
);
?>
<!-- wp:group {"tagName":"section","className":"r-help","anchor":"help","layout":{"type":"constrained","contentSize":"1440px"}} -->
<section id="help" class="wp-block-group r-help">
<!-- wp:heading {"className":"r-h2"} -->
<h2 class="wp-block-heading r-h2">How can we help <em>you today?</em></h2>
<!-- /wp:heading -->

<!-- wp:group {"className":"r-tiles","layout":{"type":"grid","columnCount":2}} -->
<div class="wp-block-group r-tiles">
<?php foreach ( $tiles as $i => $t ) : ?>
<!-- wp:group {"className":"r-tile","layout":{"type":"default"}} -->
<div class="wp-block-group r-tile"><!-- wp:image {"className":"r-tile-img"} -->
<figure class="wp-block-image r-tile-img"><img src="<?php echo raices_img( $t[0] ); ?>" alt="<?php echo esc_attr( $t[4] ); ?>"/></figure>
<!-- /wp:image -->

<!-- wp:group {"className":"r-tile-body","layout":{"type":"default"}} -->
<div class="wp-block-group r-tile-body"><!-- wp:paragraph {"className":"r-tile-num"} -->
<p class="r-tile-num">0<?php echo $i + 1; ?></p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><a href="<?php echo esc_attr( $t[3] ); ?>"><?php echo esc_html( $t[1] ); ?></a></h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php echo esc_html( $t[2] ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
<?php endforeach; ?>
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
