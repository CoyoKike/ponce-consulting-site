<?php
/**
 * Title: Give and get involved
 * Slug: raices/give
 * Categories: raices
 */
?>
<!-- wp:cover {"url":"<?php echo raices_img( 'give.webp' ); ?>","dimRatio":70,"overlayColor":"forest","className":"r-give","anchor":"give","layout":{"type":"constrained","contentSize":"1240px"}} -->
<div id="give" class="wp-block-cover r-give"><span aria-hidden="true" class="wp-block-cover__background has-forest-background-color has-background-dim-70 has-background-dim"></span><img class="wp-block-cover__image-background" alt="" src="<?php echo raices_img( 'give.webp' ); ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
<!-- wp:heading {"className":"r-give-title"} -->
<h2 class="wp-block-heading r-give-title">Keep Cedar Hill <em>home.</em></h2>
<!-- /wp:heading -->

<!-- wp:columns {"className":"r-give-cards"} -->
<div class="wp-block-columns r-give-cards"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Donate</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>$50 covers a family’s free tax return. $250 funds a month of career coaching.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"r-btn--sun"} -->
<div class="wp-block-button r-btn--sun"><a class="wp-block-button__link wp-element-button" href="#give">Give today</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Volunteer</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Prepare taxes, mentor a business owner or help at our events.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-outline r-btn--ghost"} -->
<div class="wp-block-button is-style-outline r-btn--ghost"><a class="wp-block-button__link wp-element-button" href="#give">Sign up</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Show up</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Join a tenant meeting or our monthly community dinner. Everyone is welcome.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-outline r-btn--ghost"} -->
<div class="wp-block-button is-style-outline r-btn--ghost"><a class="wp-block-button__link wp-element-button" href="#events">See events</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->
</div></div>
<!-- /wp:cover -->
