<?php
/**
 * Title: News and events
 * Slug: raices/news
 * Categories: raices
 */
?>
<!-- wp:group {"tagName":"section","className":"news","anchor":"news","layout":{"type":"default"}} -->
<section id="news" class="wp-block-group news">
<!-- wp:group {"className":"news-head","layout":{"type":"default"}} -->
<div class="wp-block-group news-head">
<!-- wp:paragraph {"className":"label mono"} -->
<p class="label mono">06 / News &amp; events</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"className":"h-big"} -->
<h2 class="wp-block-heading h-big">On the <em>block.</em></h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<ul class="news-list">
  <li><a href="#news"><span class="mono">Feb 3 · Free tax prep</span><h3>Tax season opens: walk-ins Tuesdays and Thursdays, 5 to 8 pm</h3><span class="arrow" aria-hidden="true">→</span></a></li>
  <li><a href="#news"><span class="mono">Feb 12 · Homebuyer class</span><h3>Six Saturdays to your first home, in English and Spanish</h3><span class="arrow" aria-hidden="true">→</span></a></li>
  <li><a href="#news"><span class="mono">Feb 19 · Small business</span><h3>Pop-up market on Maple Square: 30 local vendors, one afternoon</h3><span class="arrow" aria-hidden="true">→</span></a></li>
  <li><a href="#news"><span class="mono">Jan 2027 · Story</span><h3>How 48 families kept Calder Square affordable for another 40 years</h3><span class="arrow" aria-hidden="true">→</span></a></li>
</ul>
<!-- /wp:html -->
</section>
<!-- /wp:group -->
