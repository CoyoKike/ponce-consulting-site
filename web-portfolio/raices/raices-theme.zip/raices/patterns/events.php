<?php
/**
 * Title: Upcoming events
 * Slug: raices/events
 * Categories: raices
 */
$events = array(
	array( 'FEB', '03', 'Free tax prep season opens', 'Walk-ins Tue & Thu, 5–8 pm · Linden Street office', 'Taxes' ),
	array( 'FEB', '12', 'First-time homebuyer class', 'Six Saturdays · English and Spanish', 'Housing' ),
	array( 'FEB', '19', 'Small business pop-up market', 'Maple Square plaza · 11 am–4 pm', 'Business' ),
	array( 'FEB', '26', 'Community meeting: Linden Street plan', 'Library community room · 6:30 pm · Childcare provided', 'Organizing' ),
	array( 'MAR', '08', 'Job fair with 30 local employers', 'Eastside High School gym · 10 am–2 pm', 'Jobs' ),
);
?>
<!-- wp:group {"tagName":"section","className":"r-events","anchor":"events","layout":{"type":"constrained","contentSize":"1440px"}} -->
<section id="events" class="wp-block-group r-events">
<!-- wp:heading {"className":"r-h2"} -->
<h2 class="wp-block-heading r-h2">What's <em>coming up.</em></h2>
<!-- /wp:heading -->

<!-- wp:html -->
<div class="r-ev-wrap">
  <div class="r-ev-track" id="r-ev-track" tabindex="0" aria-label="Upcoming events">
  <?php foreach ( $events as $e ) : ?>
    <article class="r-ev"><div class="r-ev-date"><span><?php echo esc_html( $e[0] ); ?></span><b><?php echo esc_html( $e[1] ); ?></b></div><span class="r-ev-tag"><?php echo esc_html( $e[4] ); ?></span><h3><?php echo esc_html( $e[2] ); ?></h3><p><?php echo esc_html( $e[3] ); ?></p><a href="#events">Add to calendar →</a></article>
  <?php endforeach; ?>
  </div>
  <div class="r-ev-ui"><button class="r-ev-btn" id="r-ev-prev" aria-label="Previous events">←</button><button class="r-ev-btn" id="r-ev-next" aria-label="Next events">→</button></div>
</div>
<!-- /wp:html -->
</section>
<!-- /wp:group -->
