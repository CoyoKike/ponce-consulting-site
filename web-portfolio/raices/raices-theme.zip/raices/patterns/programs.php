<?php
/**
 * Title: Programs carousel
 * Slug: raices/programs
 * Categories: raices
 */
?>
<!-- wp:group {"tagName":"section","className":"work","anchor":"programs","layout":{"type":"default"}} -->
<section id="programs" class="wp-block-group work">
<!-- wp:group {"className":"work-head","layout":{"type":"default"}} -->
<div class="wp-block-group work-head">
<!-- wp:paragraph {"className":"label mono"} -->
<p class="label mono">03 / Programs</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"className":"h-big"} -->
<h2 class="wp-block-heading h-big">Help for <em>every chapter.</em></h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div class="car" role="region" aria-roledescription="carousel" aria-label="Programs">
  <div class="car-track" id="workTrack" tabindex="0">
    <article class="card slide"><div class="card-media"><img src="<?php echo raices_img( 'prog-1.webp' ); ?>" alt="A sunny courtyard with gardens between brick apartment buildings" loading="lazy" decoding="async"><span class="tag mono"><i></i>Waitlist open</span></div>
      <div class="card-body"><span class="mono">01 · Housing · 1,100 homes</span><h3>Affordable Rentals</h3><p>Apartments for families, seniors and people with disabilities, kept affordable for good.</p><a class="more mono" href="#homes">See buildings →</a></div></article>
    <article class="card slide"><div class="card-media"><img src="<?php echo raices_img( 'prog-2.webp' ); ?>" alt="A family of four smiling together in their backyard" loading="lazy" decoding="async"><span class="tag mono"><i></i>Spring class open</span></div>
      <div class="card-body"><span class="mono">02 · Housing · 6 Saturdays</span><h3>First-Time Homebuyers</h3><p>Classes in English and Spanish, plus down payment help for families buying in Cedar Hill.</p><a class="more mono" href="#programs">Save a seat →</a></div></article>
    <article class="card slide"><div class="card-media"><img src="<?php echo raices_img( 'prog-3.webp' ); ?>" alt="Two women going over notes together at a table" loading="lazy" decoding="async"><span class="tag mono"><i></i>Open year-round</span></div>
      <div class="card-body"><span class="mono">03 · Jobs · free</span><h3>Career Coaching</h3><p>One-on-one coaching, resume help and training that leads to jobs paying a living wage.</p><a class="more mono" href="#programs">Meet a coach →</a></div></article>
    <article class="card slide"><div class="card-media"><img src="<?php echo raices_img( 'prog-4.webp' ); ?>" alt="Hands counting a stack of cash" loading="lazy" decoding="async"><span class="tag mono closed"><i></i>Opens Feb 1</span></div>
      <div class="card-body"><span class="mono">04 · Money · walk-ins welcome</span><h3>Free Tax Prep</h3><p>IRS-certified volunteers file your return for free, so your whole refund stays with you.</p><a class="more mono" href="#programs">Book a time →</a></div></article>
    <article class="card slide"><div class="card-media"><img src="<?php echo raices_img( 'prog-5.webp' ); ?>" alt="A shop owner standing with his arms crossed in the doorway of his store" loading="lazy" decoding="async"><span class="tag mono"><i></i>Rolling · up to $50K</span></div>
      <div class="card-body"><span class="mono">05 · Business · bilingual</span><h3>Small Business Loans</h3><p>Microloans, lease help and coaching for the shops and kitchens on our corners.</p><a class="more mono" href="#programs">Check rates →</a></div></article>
    <article class="card slide"><div class="card-media"><img src="<?php echo raices_img( 'prog-6.webp' ); ?>" alt="Neighbors marching together down a city street" loading="lazy" decoding="async"><span class="tag mono"><i></i>Meets monthly</span></div>
      <div class="card-body"><span class="mono">06 · Organizing · all welcome</span><h3>Tenant Organizing</h3><p>Know your rights, meet your neighbors and have a say in how Cedar Hill grows.</p><a class="more mono" href="#news">Next meeting →</a></div></article>
  </div>
  <div class="car-ui">
    <div class="car-bar" aria-hidden="true"><i id="carBar"></i></div>
    <span class="car-count mono" aria-live="polite"><b id="carNow">01</b> / 06</span>
    <button class="car-btn" id="carPrev" aria-label="Previous programs"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M15 5l-7 7 7 7"/></svg></button>
    <button class="car-btn" id="carNext" aria-label="Next programs"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M9 5l7 7-7 7"/></svg></button>
  </div>
</div>
<!-- /wp:html -->
</section>
<!-- /wp:group -->
