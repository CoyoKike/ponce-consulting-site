<?php
/**
 * Title: Hero
 * Slug: raices/hero
 * Categories: raices
 */
?>
<!-- wp:cover {"url":"<?php echo raices_img( 'hero.webp' ); ?>","dimRatio":0,"minHeight":100,"minHeightUnit":"vh","className":"r-hero","layout":{"type":"constrained","contentSize":"1440px"}} -->
<div class="wp-block-cover r-hero" style="min-height:100vh"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background" alt="Folklórico dancers in bright swirling skirts dancing down a city street" src="<?php echo raices_img( 'hero.webp' ); ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
<!-- wp:paragraph {"className":"r-eyebrow"} -->
<p class="r-eyebrow">Cedar Hill · Since 1981</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"className":"r-hero-title"} -->
<h1 class="wp-block-heading r-hero-title">This neighborhood <em>is ours.</em></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"className":"r-hero-lede"} -->
<p class="r-hero-lede">We build homes people can afford, help families grow their income and keep local businesses open, so the people who made Cedar Hill can stay.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"className":"r-hero-ctas"} -->
<div class="wp-block-buttons r-hero-ctas"><!-- wp:button {"className":"r-btn--sun"} -->
<div class="wp-block-button r-btn--sun"><a class="wp-block-button__link wp-element-button" href="#homes">Find housing</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-outline r-btn--ghost"} -->
<div class="wp-block-button is-style-outline r-btn--ghost"><a class="wp-block-button__link wp-element-button" href="#help">Get help today</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
</div></div>
<!-- /wp:cover -->
