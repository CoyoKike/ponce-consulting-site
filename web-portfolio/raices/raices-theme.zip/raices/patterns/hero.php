<?php
/**
 * Title: Hero
 * Slug: raices/hero
 * Categories: raices
 */
?>
<!-- wp:group {"tagName":"section","className":"r-hero","layout":{"type":"default"}} -->
<section class="wp-block-group r-hero">
<!-- wp:group {"className":"r-hero-top","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} -->
<div class="wp-block-group r-hero-top">
<!-- wp:paragraph {"className":"r-eyebrow"} -->
<p class="r-eyebrow">Cedar Hill · Since 1981</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"r-eyebrow r-eyebrow--soft"} -->
<p class="r-eyebrow r-eyebrow--soft">Homes · Jobs · Small business · Organizing</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"r-hero-head","layout":{"type":"default"}} -->
<div class="wp-block-group r-hero-head">
<!-- wp:heading {"level":1,"className":"r-hero-title"} -->
<h1 class="wp-block-heading r-hero-title">This neighborhood <em>is ours.</em></h1>
<!-- /wp:heading -->

<!-- wp:html -->
<a class="r-badge" href="#help" aria-label="Scroll to learn more"><svg viewBox="0 0 200 200" aria-hidden="true"><defs><path id="r-badge-path" d="M100,100 m-80,0 a80,80 0 1,1 160,0 a80,80 0 1,1 -160,0"/></defs><text><textPath href="#r-badge-path" textLength="498" lengthAdjust="spacing">Hablamos español · Since 1981 · Cedar Hill ·</textPath></text></svg><span aria-hidden="true">↓</span></a>
<!-- /wp:html -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"r-hero-row","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
<div class="wp-block-group r-hero-row">
<!-- wp:paragraph {"className":"r-hero-lede"} -->
<p class="r-hero-lede">We build homes people can afford, help families grow their income and keep local businesses open, so the people who made Cedar Hill can stay.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"className":"r-hero-ctas"} -->
<div class="wp-block-buttons r-hero-ctas"><!-- wp:button {"className":"r-btn--sun"} -->
<div class="wp-block-button r-btn--sun"><a class="wp-block-button__link wp-element-button" href="#homes">Find housing</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"r-btn--line"} -->
<div class="wp-block-button r-btn--line"><a class="wp-block-button__link wp-element-button" href="#help">Get help today</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"r-stage","layout":{"type":"default"}} -->
<div class="wp-block-group r-stage">
<!-- wp:image {"sizeSlug":"full","className":"r-stage-main"} -->
<figure class="wp-block-image size-full r-stage-main"><img src="<?php echo raices_img( 'hero.webp' ); ?>" alt="Folklórico dancers in bright swirling skirts dancing down a city street"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","className":"r-stage-side r-stage-l"} -->
<figure class="wp-block-image size-full r-stage-side r-stage-l"><img src="<?php echo raices_img( 'help-coaching.webp' ); ?>" alt="A coach and a neighbor going over a budget together"/></figure>
<!-- /wp:image -->

<!-- wp:image {"sizeSlug":"full","className":"r-stage-side r-stage-r"} -->
<figure class="wp-block-image size-full r-stage-side r-stage-r"><img src="<?php echo raices_img( 'work-organizing.webp' ); ?>" alt="Neighbors at a community meeting"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"r-stage-cap"} -->
<p class="r-stage-cap">Every August, Linden Street closes for Fiesta de la Calle. <em>Everyone is invited.</em></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:html -->
<div class="r-marquee" aria-hidden="true"><div class="r-marquee-track"><span>Affordable homes</span><i>✺</i><span lang="es">Vivienda asequible</span><i>✺</i><span>Financial coaching</span><i>✺</i><span lang="es">Empleos</span><i>✺</i><span>Small business loans</span><i>✺</i><span lang="es">Organización</span><i>✺</i><span>Tenant rights</span><i>✺</i></div></div>
<!-- /wp:html -->
</section>
<!-- /wp:group -->
