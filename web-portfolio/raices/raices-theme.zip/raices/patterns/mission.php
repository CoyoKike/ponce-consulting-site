<?php
/**
 * Title: Mission
 * Slug: raices/mission
 * Categories: raices
 */
?>
<!-- wp:group {"tagName":"section","className":"r-mission","layout":{"type":"constrained","contentSize":"1320px"}} -->
<section class="wp-block-group r-mission">
<!-- wp:paragraph {"className":"r-label"} -->
<p class="r-label">Our mission</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"r-mission-text"} -->
<p class="r-mission-text">For more than forty years we have built <mark class="hl">homes people can afford</mark>, helped families <mark class="hl">build savings and careers</mark>, and kept <mark class="hl">small businesses on our corners</mark>, so this neighborhood stays home for the people who made it.</p>
<!-- /wp:paragraph -->

<!-- wp:columns {"className":"r-mission-sign"} -->
<div class="wp-block-columns r-mission-sign"><!-- wp:column {"width":"120px"} -->
<div class="wp-block-column" style="flex-basis:120px"><!-- wp:image {"className":"r-sign-photo"} -->
<figure class="wp-block-image r-sign-photo"><img src="<?php echo raices_img( 'director.webp' ); ?>" alt="Portrait of Raíces executive director Marisol Vega"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"r-sign-quote"} -->
<p class="r-sign-quote">“Every family we help stay in Cedar Hill keeps a little more of this neighborhood’s story alive.”</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"r-sign-name"} -->
<p class="r-sign-name">Marisol Vega · Executive Director</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->
</section>
<!-- /wp:group -->
