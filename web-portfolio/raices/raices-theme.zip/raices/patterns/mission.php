<?php
/**
 * Title: Mission
 * Slug: raices/mission
 * Categories: raices
 */
?>
<!-- wp:group {"tagName":"section","className":"statement mission","anchor":"about","layout":{"type":"default"}} -->
<section id="about" class="wp-block-group statement mission">
<!-- wp:group {"className":"statement-inner","layout":{"type":"default"}} -->
<div class="wp-block-group statement-inner">
<!-- wp:paragraph {"className":"label mono"} -->
<p class="label mono">01 / Our mission</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"statement-text","anchor":"statementText"} -->
<p id="statementText" class="statement-text">We believe the families who raise their kids here, <span class="pill"><img src="<?php echo raices_img( 'pill-1.webp' ); ?>" alt=""></span> open the shops <span class="pill"><img src="<?php echo raices_img( 'pill-2.webp' ); ?>" alt=""></span> and care for our elders <span class="pill"><img src="<?php echo raices_img( 'pill-3.webp' ); ?>" alt=""></span> should <em>get to stay.</em> So we build homes, grow paychecks and back local business until no one has to choose between this neighborhood and a future.</p>
<!-- /wp:paragraph -->

<!-- wp:html -->
<ol class="pillars">
  <li><span class="mono">01</span><h3>Homes that <em>stay affordable</em></h3><p>We build, own and protect 1,100 apartments that will never go to market rate.</p></li>
  <li><span class="mono">02</span><h3>Paychecks that <em>grow</em></h3><p>Coaching, training and free tax prep that put more money in families' pockets.</p></li>
  <li><span class="mono">03</span><h3>Corners that <em>stay open</em></h3><p>Loans and hands-on help for the bodegas, salons and kitchens that make this place home.</p></li>
</ol>
<div class="statement-figs">
  <figure class="sfig sfig-a" data-speed="-0.16"><img src="<?php echo raices_img( 'fig-a.webp' ); ?>" alt="A vendor smiling at her stall in the neighborhood market" loading="lazy" decoding="async"></figure>
  <figure class="sfig sfig-b" data-speed="0.12"><img src="<?php echo raices_img( 'fig-b.webp' ); ?>" alt="Neighbors talking and laughing at a community workshop" loading="lazy" decoding="async"></figure>
</div>
<!-- /wp:html -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
