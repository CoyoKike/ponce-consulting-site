<?php
/**
 * Raíces theme setup.
 */

add_action( 'after_setup_theme', function () {
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/css/site.css' );
} );

add_action( 'wp_enqueue_scripts', function () {
	$v   = wp_get_theme()->get( 'Version' );
	$uri = get_theme_file_uri();
	wp_enqueue_style( 'raices-site', $uri . '/assets/css/site.css', array(), $v );
	wp_enqueue_script( 'gsap', $uri . '/assets/vendor/gsap.min.js', array(), '3', true );
	wp_enqueue_script( 'gsap-st', $uri . '/assets/vendor/ScrollTrigger.min.js', array( 'gsap' ), '3', true );
	wp_enqueue_script( 'lenis', $uri . '/assets/vendor/lenis.min.js', array(), '1', true );
	wp_enqueue_script( 'raices-site', $uri . '/assets/js/site.js', array( 'gsap', 'gsap-st', 'lenis' ), $v, true );
} );

add_action( 'init', function () {
	register_block_pattern_category( 'raices', array( 'label' => __( 'Raíces sections', 'raices' ) ) );
} );

/** Helper for pattern files: theme image URL. */
function raices_img( $file ) {
	return esc_url( get_theme_file_uri( 'assets/img/' . $file ) );
}
